"""
kinetics.py — Phase-transformation kinetics.

Implements:
  * fe_c_critical_temperatures(comp) — A1, A3, Ms (Andrews), Mf
  * compute_transformation(comp, T_final_C, cooling_rate_K_per_s) — phase fractions
  * grain_growth(T_C, t_min, alloy_system)
  * generate_ttt / generate_cct (C-curves)
"""
from __future__ import annotations

import math
from typing import Dict, List

R_GAS = 8.314  # J/(mol·K)


def _C(comp: Dict[str, float]) -> float:
    return float(comp.get("C", 0.0))


def _Mn(comp: Dict[str, float]) -> float:
    return float(comp.get("Mn", 0.0))


def _Ni(comp: Dict[str, float]) -> float:
    return float(comp.get("Ni", 0.0))


def _Cr(comp: Dict[str, float]) -> float:
    return float(comp.get("Cr", 0.0))


def _Mo(comp: Dict[str, float]) -> float:
    return float(comp.get("Mo", 0.0))


def _Si(comp: Dict[str, float]) -> float:
    return float(comp.get("Si", 0.0))


def _Co(comp: Dict[str, float]) -> float:
    return float(comp.get("Co", 0.0))


# ----------------------------------------------------------------------
# Critical temperatures (Fe-C)
# ----------------------------------------------------------------------
def fe_c_critical_temperatures(comp: Dict[str, float]) -> Dict[str, float]:
    """
    A1 = 727 °C (eutectoid, fixed for Fe-C)
    A3 = 910 - 200*C - 30*Mn - 11*Cr - 20*Ni - 50*Mo - 60*Si
    Ms = 539 - 423*C - 30.4*Mn - 17.7*Ni - 12.1*Cr - 7.5*Mo + 10*Co - 7.5*Si  (Andrews)
    Mf = Ms - 215
    """
    C = _C(comp); Mn = _Mn(comp); Ni = _Ni(comp); Cr = _Cr(comp); Mo = _Mo(comp); Si = _Si(comp); Co = _Co(comp)
    A1 = 727.0
    A3 = 910.0 - 200.0 * C - 30.0 * Mn - 11.0 * Cr - 20.0 * Ni - 50.0 * Mo - 60.0 * Si
    Ms = 539.0 - 423.0 * C - 30.4 * Mn - 17.7 * Ni - 12.1 * Cr - 7.5 * Mo + 10.0 * Co - 7.5 * Si
    Mf = Ms - 215.0
    return {
        "A1_C": round(A1, 2),
        "A3_C": round(A3, 2),
        "Ms_C": round(Ms, 2),
        "Mf_C": round(Mf, 2),
    }


def _critical_full_martensite_rate(comp: Dict[str, float]) -> float:
    """
    Critical cooling rate (K/s) above which the steel is fully martensitic
    if quenched below Ms. Approximated from carbon equivalent.
    CE = C + Mn/6 + Cr/5 + Mo/4 + Ni/15  (IIW)
    Higher CE → lower critical rate (hardenability ↑).
    """
    C = _C(comp); Mn = _Mn(comp); Ni = _Ni(comp); Cr = _Cr(comp); Mo = _Mo(comp); Si = _Si(comp)
    CE = C + Mn / 6.0 + Cr / 5.0 + Mo / 4.0 + Ni / 15.0 + Si / 24.0
    # Empirical: rcrit ≈ 60 * exp(-3.2 * CE)   K/s
    rc = 60.0 * math.exp(-3.2 * max(0.0, CE))
    return max(0.5, rc)


# ----------------------------------------------------------------------
# Phase transformation
# ----------------------------------------------------------------------
def _jmak(t_s: float, k0: float, Q: float, T_K: float, n: float) -> float:
    """JMAK fraction X = 1 - exp(-(k*t)^n), k = k0*exp(-Q/RT)."""
    k = k0 * math.exp(-Q / (R_GAS * T_K))
    return 1.0 - math.exp(-((k * max(0.0, t_s)) ** n))


def compute_transformation(
    comp: Dict[str, float],
    T_final_C: float,
    cooling_rate_K_per_s: float,
    t_at_T_s: float = 0.0,
) -> Dict[str, float]:
    """
    Compute the final phase fractions after cooling from austenite to T_final_C
    at cooling_rate_K_per_s.

    Returns dict with martensite, bainite, ferrite, pearlite,
    retained_austenite, cementite (all in 0..1, sum to 1).
    """
    sys_default = {"C": 0.4}
    comp = {**sys_default, **(comp or {})}
    crit = fe_c_critical_temperatures(comp)
    Ms = crit["Ms_C"]
    Mf = crit["Mf_C"]
    A1 = crit["A1_C"]
    A3 = crit["A3_C"]

    rcrit = _critical_full_martensite_rate(comp)

    # Initialize all phases to 0
    out = {
        "martensite": 0.0,
        "bainite": 0.0,
        "ferrite": 0.0,
        "pearlite": 0.0,
        "retained_austenite": 0.0,
        "cementite": 0.0,
    }

    C = _C(comp)

    # Cooling rate is in K/min elsewhere; here it's K/s. The caller passes K/s.
    cr_Ks = float(cooling_rate_K_per_s)

    # Effective hold time at T_final (used for diffusional growth below A1)
    eff_t = max(1.0, t_at_T_s)

    if T_final_C >= A3:
        # Still austenite
        out["retained_austenite"] = 1.0
        return _round_phases(out)

    # Martensitic transformation if final T below Ms
    martensite_frac = 0.0
    if T_final_C < Ms:
        if cr_Ks >= rcrit:
            # Mostly martensitic
            martensite_frac = 1.0 - math.exp(-0.011 * (Ms - T_final_C))
            martensite_frac = max(0.0, min(1.0, martensite_frac))
        elif cr_Ks >= rcrit * 0.3:
            # Mixed martensite + diffusional
            martensite_frac = 0.5 * (1.0 - math.exp(-0.011 * (Ms - T_final_C)))

    # Diffusional fractions via JMAK
    T_K = max(1.0, T_final_C + 273.15)
    # Pearlite: fastest near A1 (≈ 727°C) — n=2, Q=120 kJ/mol
    pearlite_frac = 0.0
    if A1 - 60.0 <= T_final_C <= A1 + 20.0:
        pearlite_frac = _jmak(eff_t, k0=1.0e6, Q=120_000.0, T_K=T_K, n=2.0)
    # Bainite: 250–550 °C — n=2.5, Q=90 kJ/mol
    bainite_frac = 0.0
    if 250.0 <= T_final_C <= 550.0:
        bainite_frac = _jmak(eff_t, k0=1.0e5, Q=90_000.0, T_K=T_K, n=2.5)
    # Ferrite: hypoeutectoid, 550–A3, n=2
    ferrite_frac = 0.0
    if A1 < T_final_C < A3 and C < 0.77:
        ferrite_frac = _jmak(eff_t, k0=5.0e4, Q=140_000.0, T_K=T_K, n=2.0)

    # Normalize diffusional so they don't overlap martensite
    diff_total = pearlite_frac + bainite_frac + ferrite_frac
    if diff_total > 1.0:
        scale = 1.0 / diff_total
        pearlite_frac *= scale
        bainite_frac *= scale
        ferrite_frac *= scale
        diff_total = 1.0

    remaining = 1.0 - martensite_frac
    if diff_total > 0:
        # Scale diffusional into the remaining fraction
        pearlite_frac *= remaining / diff_total if diff_total > 0 else 0.0
        bainite_frac *= remaining / diff_total if diff_total > 0 else 0.0
        ferrite_frac *= remaining / diff_total if diff_total > 0 else 0.0
    else:
        # No diffusional growth — fill with ferrite/pearlite default based on C
        if C < 0.77:
            ferrite_frac = remaining * (1.0 - C / 0.77)
            cementite_frac = remaining * (C / 0.77) * 0.5
            pearlite_frac = remaining - ferrite_frac - cementite_frac
            out["ferrite"] = max(0.0, ferrite_frac)
            out["pearlite"] = max(0.0, pearlite_frac)
            out["cementite"] = max(0.0, cementite_frac)
            out["martensite"] = max(0.0, martensite_frac)
            out["retained_austenite"] = max(0.0, 1.0 - sum(out.values()))
            return _round_phases(out)

    # Cementite from carbon partitioning
    cementite_frac = 0.0
    if C > 0.022 and T_final_C < A1:
        # Rough: a few % of the non-martensitic fraction becomes cementite
        cementite_frac = min(0.15, 0.04 + (C - 0.022) * 1.5) * (1.0 - martensite_frac)

    # Rescale diffusional to make room for cementite
    diff_total2 = pearlite_frac + bainite_frac + ferrite_frac + cementite_frac
    if diff_total2 > (1.0 - martensite_frac):
        norm = (1.0 - martensite_frac) / diff_total2
        pearlite_frac *= norm
        bainite_frac *= norm
        ferrite_frac *= norm
        cementite_frac *= norm

    out["martensite"] = max(0.0, martensite_frac)
    out["pearlite"] = max(0.0, pearlite_frac)
    out["bainite"] = max(0.0, bainite_frac)
    out["ferrite"] = max(0.0, ferrite_frac)
    out["cementite"] = max(0.0, cementite_frac)

    # Retained austenite
    ra = 1.0 - sum(out.values())
    out["retained_austenite"] = max(0.0, ra)
    if T_final_C >= Ms:
        # If final T above Ms, austenite doesn't transform to martensite at all.
        # Reallocate martensite to retained austenite.
        out["retained_austenite"] += out["martensite"]
        out["martensite"] = 0.0
        out["retained_austenite"] = min(1.0, out["retained_austenite"])

    return _round_phases(out)


def _round_phases(d: Dict[str, float]) -> Dict[str, float]:
    return {k: round(max(0.0, v), 4) for k, v in d.items()}


# ----------------------------------------------------------------------
# Grain growth
# ----------------------------------------------------------------------
# (Q in J/mol, K0 in m²/s, baseline d0 in µm)
GRAIN_PARAMS = {
    "Fe-C":     {"Q": 280_000.0, "K0": 8.0e-3,  "d0_um": 20.0},
    "Al-Cu":    {"Q": 140_000.0, "K0": 2.0e-4,  "d0_um": 50.0},
    "Al-Si":    {"Q": 140_000.0, "K0": 2.0e-4,  "d0_um": 50.0},
    "Ni-Cr-Co": {"Q": 320_000.0, "K0": 1.0e-3,  "d0_um": 30.0},
}


def grain_growth(T_C: float, t_min: float, alloy_system: str) -> Dict[str, float]:
    """
    Parabolic Arrhenius grain growth:
        d² = d0² + K0 * exp(-Q/RT) * t

    Returns {grain_size_um, growth_factor}.
    """
    params = GRAIN_PARAMS.get(alloy_system, GRAIN_PARAMS["Fe-C"])
    d0 = params["d0_um"]
    K0 = params["K0"]
    Q = params["Q"]
    T_K = max(300.0, T_C + 273.15)
    t_s = max(0.0, t_min) * 60.0
    d_squared = (d0 ** 2) + K0 * math.exp(-Q / (R_GAS * T_K)) * t_s * 1e12  # µm²
    d = math.sqrt(max(d0 ** 2, d_squared))
    growth = d / d0 if d0 > 0 else 1.0
    return {"grain_size_um": round(d, 3), "growth_factor": round(growth, 3)}


# ----------------------------------------------------------------------
# TTT / CCT
# ----------------------------------------------------------------------
def _c_curve(
    T_start_C: float,
    T_finish_C: float,
    t_min_s: float,
    t_max_s: float,
    n: int = 24,
    n_avrami: float = 2.0,
    Q: float = 120_000.0,
    k0: float = 1.0e6,
) -> List[Dict[str, float]]:
    """
    Build a C-curve for a single transformation (start/finish temperatures).

    Each point: {T_C, t_s, fraction}.
    The 'nose' is at the temperature where k(T) is maximal — i.e. lowest T in
    the allowed band (here we just use the average of T_start and T_finish).
    """
    out: List[Dict[str, float]] = []
    import math as _m
    T_nose = 0.5 * (T_start_C + T_finish_C)
    # Time scale sweeps logarithmically
    import numpy as np
    ts = np.logspace(_m.log10(max(0.1, t_min_s)), _m.log10(max(t_min_s * 1.5, t_max_s)), n)
    for t_s in ts:
        T_K = T_nose + 273.15
        k = k0 * _m.exp(-Q / (R_GAS * T_K))
        X = 1.0 - _m.exp(-((k * float(t_s)) ** n_avrami))
        out.append({
            "T_C": round(T_nose, 2),
            "t_s": round(float(t_s), 4),
            "t_log10": round(_m.log10(max(1e-3, float(t_s))), 4),
            "fraction": round(X, 4),
        })
    return out


def generate_ttt(alloy: "Alloy") -> Dict[str, object]:
    """
    Generate TTT diagram curves.

    Returns curves keyed by transformation name:
      ferrite_start, ferrite_finish,
      pearlite_start, pearlite_finish,
      bainite_start, bainite_finish,
      martensite_start (Ms), martensite_finish (Mf).
    """
    from models import Alloy as _Alloy  # local import to avoid cycle
    if not isinstance(alloy, _Alloy):
        alloy = _Alloy(**alloy) if isinstance(alloy, dict) else alloy

    sys_id = alloy.system
    comp = alloy.composition or {"C": 0.4}

    if sys_id == "Fe-C":
        crit = fe_c_critical_temperatures(comp)
        A1 = crit["A1_C"]; A3 = crit["A3_C"]; Ms = crit["Ms_C"]; Mf = crit["Mf_C"]

        ferrite_start = _c_curve(A1 + 20, A3 - 20, 1.0, 1e5, n=20, n_avrami=2.0, Q=140_000.0, k0=5e4)
        ferrite_finish = _c_curve(A1 + 20, A3 - 20, 5.0, 1e6, n=20, n_avrami=2.0, Q=140_000.0, k0=5e4)
        pearlite_start = _c_curve(A1 - 50, A1 + 20, 1.0, 1e4, n=20, n_avrami=2.0, Q=120_000.0, k0=1e6)
        pearlite_finish = _c_curve(A1 - 50, A1 + 20, 5.0, 1e5, n=20, n_avrami=2.0, Q=120_000.0, k0=1e6)
        bainite_start = _c_curve(max(250.0, Ms), A1 - 30, 2.0, 1e5, n=20, n_avrami=2.5, Q=90_000.0, k0=1e5)
        bainite_finish = _c_curve(max(250.0, Ms), A1 - 30, 8.0, 1e6, n=20, n_avrami=2.5, Q=90_000.0, k0=1e5)

        curves = {
            "ferrite_start": ferrite_start,
            "ferrite_finish": ferrite_finish,
            "pearlite_start": pearlite_start,
            "pearlite_finish": pearlite_finish,
            "bainite_start": bainite_start,
            "bainite_finish": bainite_finish,
            "martensite_start": [{"T_C": Ms, "t_s": 0.0, "t_log10": 0.0, "fraction": 0.0}],
            "martensite_finish": [{"T_C": Mf, "t_s": 0.0, "t_log10": 0.0, "fraction": 1.0}],
        }
        return {
            "curves": curves,
            "Ms_C": Ms,
            "Mf_C": Mf,
            "A1_C": A1,
            "A3_C": A3,
        }

    # Non-Fe systems: simplified TTT (one curve for the main precipitate)
    if sys_id == "Al-Cu":
        solvus = 540.0
        gp_zone = _c_curve(20, 180, 60.0, 1e6, n=18, n_avrami=1.5, Q=80_000.0, k0=1e3)
        theta_prime = _c_curve(150, 300, 60.0, 1e6, n=18, n_avrami=2.0, Q=110_000.0, k0=5e3)
        theta_stable = _c_curve(300, solvus, 60.0, 1e7, n=18, n_avrami=2.0, Q=140_000.0, k0=1e4)
        curves = {
            "gp_zones_start": gp_zone,
            "theta_prime_start": theta_prime,
            "theta_stable_start": theta_stable,
            "solvus_C": [{"T_C": solvus, "t_s": 0.0, "t_log10": 0.0, "fraction": 0.0}],
        }
        return {"curves": curves, "Ms_C": None, "Mf_C": None, "A1_C": None, "A3_C": None}

    if sys_id == "Al-Si":
        eutectic = 577.0
        si_precip = _c_curve(200, 400, 60.0, 1e6, n=18, n_avrami=2.0, Q=120_000.0, k0=1e4)
        curves = {
            "si_precipitate_start": si_precip,
            "eutectic_C": [{"T_C": eutectic, "t_s": 0.0, "t_log10": 0.0, "fraction": 0.0}],
        }
        return {"curves": curves, "Ms_C": None, "Mf_C": None, "A1_C": None, "A3_C": None}

    if sys_id == "Ni-Cr-Co":
        gamma_prime_solvus = 850.0
        gp = _c_curve(600, 900, 60.0, 1e7, n=18, n_avrami=2.5, Q=250_000.0, k0=1e5)
        carbide = _c_curve(700, 1000, 60.0, 1e7, n=18, n_avrami=2.0, Q=200_000.0, k0=5e4)
        curves = {
            "gamma_prime_start": gp,
            "carbide_start": carbide,
            "gamma_prime_solvus_C": [{"T_C": gamma_prime_solvus, "t_s": 0.0, "t_log10": 0.0, "fraction": 0.0}],
        }
        return {"curves": curves, "Ms_C": None, "Mf_C": None, "A1_C": None, "A3_C": None}

    return {"curves": {}, "Ms_C": None, "Mf_C": None, "A1_C": None, "A3_C": None}


def generate_cct(alloy: "Alloy", cooling_rates_K_per_s: List[float]) -> Dict[str, object]:
    """
    Generate CCT diagram by shifting TTT curves rightward as a function of
    cooling rate. For each cooling rate we report the transformation-start
    time and temperature for each phase.

    Returns curves: {cooling_rate_K_per_s: [{T_C, t_s, fraction, phase}, ...]}
    """
    ttt = generate_ttt(alloy)
    base_curves = ttt["curves"]

    cct: Dict[str, List[Dict[str, object]]] = {}
    for cr in cooling_rates_K_per_s:
        # Shift factor: faster cooling → shift right (larger t)
        shift = 1.0 + 0.5 * cr  # rough
        rows: List[Dict[str, object]] = []
        for phase, pts in base_curves.items():
            if not pts:
                continue
            for p in pts:
                if p.get("t_s", 0) <= 0:
                    continue
                rows.append({
                    "T_C": p["T_C"],
                    "t_s": round(p["t_s"] * shift, 3),
                    "t_log10": round(math.log10(max(1e-3, p["t_s"] * shift)), 4),
                    "fraction": p.get("fraction", 0.5),
                    "phase": phase,
                    "cooling_rate_K_per_s": cr,
                })
        cct[str(round(cr, 3))] = rows
    return {
        "curves": cct,
        "Ms_C": ttt.get("Ms_C"),
        "Mf_C": ttt.get("Mf_C"),
        "A1_C": ttt.get("A1_C"),
        "A3_C": ttt.get("A3_C"),
        "cooling_rates_K_per_s": cooling_rates_K_per_s,
    }


# ----------------------------------------------------------------------
# Hollomon-Jaffe tempering parameter
# ----------------------------------------------------------------------
def hollomon_jaffe(T_C: float, t_h: float, C_const: float = 20.0) -> float:
    """
    Hollomon-Jaffe parameter:
        HJP = T(K) * (C + log10(t_h))   [t in hours]
    """
    T_K = T_C + 273.15
    t_h_hours = max(1e-4, t_h) / 60.0
    return round(T_K * (C_const + math.log10(t_h_hours)), 2)

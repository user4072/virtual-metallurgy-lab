#!/bin/bash
cd "$(dirname "$0")"
source /home/z/.venv/bin/activate
exec python -m uvicorn server:app --host 0.0.0.0 --port 8000 --reload

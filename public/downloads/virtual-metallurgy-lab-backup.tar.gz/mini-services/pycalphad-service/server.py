#!/usr/bin/env python3
"""
pycalphad-service — REAL CALPHAD equilibrium calculations for ALL alloy systems.
Runs on port 8000.

Databases:
  Al-Cu, Al-Si:  COST507.tdb (shipped with pycalphad)
  Fe-C:           Fe-C.tdb (Gustafsson assessment, custom)
  Ni-Cr-Co:       Ni-Cr-Co.tdb (Gu & Du assessment, custom)

Endpoints:
  GET  /health                 — service health
  POST /pycalphad/phase        — equilibrium phase fractions for any alloy system
"""
import sys
import os
import numpy as np
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from pycalphad import Database, equilibrium, variables as v
import uvicorn

SERVICE_DIR = os.path.dirname(os.path.abspath(__file__))

# ---- Load databases ----
COST507_PATH = "/home/z/.venv/lib/python3.12/site-packages/pycalphad/tests/databases/COST507.tdb"

print("Loading databases...", file=sys.stderr)
DB_COST507 = Database(COST507_PATH)
DB_FEC = Database(os.path.join(SERVICE_DIR, "Fe-C.tdb"))
DB_NICRCO = Database(os.path.join(SERVICE_DIR, "Ni-Cr-Co.tdb"))
print("All databases loaded.", file=sys.stderr)

# ---- System configurations ----
# Each system maps to: (database, elements, phases, phase_name_map, atomic_weights)
SYSTEMS = {
    "Al-Cu": {
        "db": DB_COST507,
        "elements": ["AL", "CU", "VA"],
        "phases": ["FCC_A1", "ALCU_THETA", "LIQUID"],
        "map": {"FCC_A1": "α-Al (FCC)", "ALCU_THETA": "θ-Al₂Cu", "LIQUID": "Liquid"},
        "solute": "CU",
        "solvent": "AL",
        "aw": {"AL": 26.982, "CU": 63.546},
    },
    "Al-Si": {
        "db": DB_COST507,
        "elements": ["AL", "SI", "VA"],
        "phases": ["FCC_A1", "DIAMOND_A4", "LIQUID"],
        "map": {"FCC_A1": "α-Al (FCC)", "DIAMOND_A4": "β-Si", "LIQUID": "Liquid"},
        "solute": "SI",
        "solvent": "AL",
        "aw": {"AL": 26.982, "SI": 28.086},
    },
    "Fe-C": {
        "db": DB_FEC,
        "elements": ["FE", "C", "VA"],
        "phases": ["BCC_A2", "FCC_A1", "CEMENTITE", "LIQUID"],
        "map": {"BCC_A2": "α-Fe (BCC)", "FCC_A1": "γ-Fe (Austenite)", "CEMENTITE": "Fe₃C", "LIQUID": "Liquid"},
        "solute": "C",
        "solvent": "FE",
        "aw": {"FE": 55.845, "C": 12.011},
    },
    "Ni-Cr-Co": {
        "db": DB_NICRCO,
        "elements": ["NI", "CR", "CO", "VA"],
        "phases": ["FCC_A1", "BCC_A2", "LIQUID"],
        "map": {"FCC_A1": "γ-Ni (FCC)", "BCC_A2": "α-Cr (BCC)", "LIQUID": "Liquid"},
        "solute": "CR",
        "solute2": "CO",
        "solvent": "NI",
        "aw": {"NI": 58.693, "CR": 51.996, "CO": 58.933},
    },
}


def wt_to_mol(wt_frac, elem, aw_dict):
    """Convert weight fraction to mole fraction for a binary/ternary."""
    if elem == "Ni-Cr-Co":
        # ternary: wt_fracs for Cr and Co
        xCr_wt, xCo_wt = wt_frac
        xNi_wt = max(0, 1 - xCr_wt - xCo_wt)
        nCr = xCr_wt / aw_dict["CR"]
        nCo = xCo_wt / aw_dict["CO"]
        nNi = xNi_wt / aw_dict["NI"]
        total = nCr + nCo + nNi
        return nCr / total, nCo / total
    else:
        # binary: wt_frac is solute weight fraction
        solute = SYSTEMS[elem]["solute"]
        solvent = SYSTEMS[elem]["solvent"]
        x_solute_wt = wt_frac
        x_solvent_wt = 1 - x_solute_wt
        n_solute = x_solute_wt / aw_dict[solute]
        n_solvent = x_solvent_wt / aw_dict[solvent]
        return n_solute / (n_solute + n_solvent)


app = FastAPI(title="pycalphad service for VML")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


class PhaseRequest(BaseModel):
    alloySystem: str = "Al-Cu"
    soluteFraction: float = 0.04   # weight fraction
    soluteFraction2: float = 0.10  # weight fraction (Co for ternary)
    temperatureC: float = 25.0


@app.get("/health")
def health():
    return {"ok": True, "pycalphad": True, "systems": list(SYSTEMS.keys())}


@app.post("/pycalphad/phase")
def calc_phase(req: PhaseRequest):
    """Calculate equilibrium phase fractions using real pycalphad."""
    try:
        sys_id = req.alloySystem
        if sys_id not in SYSTEMS:
            return {"ok": False, "error": f"Unknown system: {sys_id}", "pycalphad": True}

        cfg = SYSTEMS[sys_id]
        db = cfg["db"]
        elements = cfg["elements"]
        phases_list = cfg["phases"]
        phase_map = cfg["map"]
        aw = cfg["aw"]

        T = req.temperatureC + 273.15

        # Convert weight fractions to mole fractions
        if sys_id == "Ni-Cr-Co":
            xCr_mol, xCo_mol = wt_to_mol((req.soluteFraction, req.soluteFraction2), "Ni-Cr-Co", aw)
            xCr_mol = max(0.001, min(0.998, xCr_mol))
            xCo_mol = max(0.001, min(0.998 - xCr_mol, xCo_mol))
            conditions = {v.T: T, v.P: 101325, v.X("CR"): xCr_mol, v.X("CO"): xCo_mol}
        else:
            x_mol = wt_to_mol(req.soluteFraction, sys_id, aw)
            x_mol = max(0.0001, min(0.999, x_mol))
            solute = cfg["solute"]
            conditions = {v.T: T, v.P: 101325, v.X(solute): x_mol}

        eq = equilibrium(db, elements, phases_list, conditions)

        # Extract phase fractions
        eq_phases = eq.Phase.values.flatten()
        eq_fracs = eq.NP.values.flatten()
        result = {}
        for i, p in enumerate(eq_phases):
            if p and not (isinstance(p, float) and np.isnan(p)):
                frac = float(eq_fracs[i]) if not np.isnan(eq_fracs[i]) else 0.0
                if frac > 0.001:
                    display = phase_map.get(p, p)
                    result[display] = round(frac, 4)

        if not result:
            result = {"Unknown": 1.0}

        dominant = max(result, key=result.get)
        return {
            "ok": True,
            "pycalphad": True,
            "alloySystem": sys_id,
            "soluteFraction": req.soluteFraction,
            "soluteFraction2": req.soluteFraction2,
            "temperatureC": req.temperatureC,
            "phases": result,
            "dominantPhase": dominant,
        }
    except Exception as e:
        return {"ok": False, "error": str(e), "pycalphad": True}


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)

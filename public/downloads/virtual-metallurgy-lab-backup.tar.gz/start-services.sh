#!/bin/bash
# Start both backend services (pycalphad + heat-treatment) and keep them running.
# Usage: nohup bash /home/z/my-project/start-services.sh > /dev/null 2>&1 &

PY=/home/z/.venv/bin/python
PYCALPHAD_DIR=/home/z/my-project/mini-services/pycalphad-service
HT_DIR=/home/z/my-project/mini-services/heat-treatment-service

# Kill any existing instances
pkill -f "uvicorn server:app" 2>/dev/null
pkill -f "uvicorn main:app" 2>/dev/null
sleep 1

# Start pycalphad service (port 8000)
setsid $PY -m uvicorn server:app --host 0.0.0.0 --port 8000 --app-dir "$PYCALPHAD_DIR" \
  > /home/z/my-project/pycalphad.log 2>&1 < /dev/null &
echo "pycalphad started (PID $!)"

# Wait for pycalphad to be ready
for i in $(seq 1 10); do
  if curl -s http://localhost:8000/health > /dev/null 2>&1; then
    echo "pycalphad ready"
    break
  fi
  sleep 1
done

# Start heat-treatment service (port 8001)
setsid $PY -m uvicorn main:app --host 0.0.0.0 --port 8001 --app-dir "$HT_DIR" \
  > /home/z/my-project/ht-service.log 2>&1 < /dev/null &
echo "heat-treatment started (PID $!)"

# Wait for HT to be ready
for i in $(seq 1 10); do
  if curl -s http://localhost:8001/health > /dev/null 2>&1; then
    echo "heat-treatment ready"
    break
  fi
  sleep 1
done

# Keep the script alive so the services aren't orphaned
echo "Services running. Press Ctrl+C to stop."
exec tail -f /dev/null

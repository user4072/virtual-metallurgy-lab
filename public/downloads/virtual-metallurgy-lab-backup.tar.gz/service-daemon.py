#!/usr/bin/env python3
"""Daemon that keeps both backend services alive."""
import subprocess
import time
import sys
import os
import signal

PY = "/home/z/.venv/bin/python"
SRVICES = [
    {
        "name": "pycalphad",
        "cmd": [PY, "-m", "uvicorn", "server:app", "--host", "0.0.0.0", "--port", "8000",
                "--app-dir", "/home/z/my-project/mini-services/pycalphad-service"],
        "log": "/home/z/my-project/pycalphad.log",
        "port": 8000,
    },
    {
        "name": "heat-treatment",
        "cmd": [PY, "-m", "uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8001",
                "--app-dir", "/home/z/my-project/mini-services/heat-treatment-service"],
        "log": "/home/z/my-project/ht-service.log",
        "port": 8001,
    },
]

def is_alive(port):
    try:
        import urllib.request
        urllib.request.urlopen(f"http://localhost:{port}/health", timeout=2)
        return True
    except:
        return False

def start_service(svc):
    if is_alive(svc["port"]):
        print(f"{svc['name']} already running on port {svc['port']}")
        return None
    logf = open(svc["log"], "a")
    proc = subprocess.Popen(svc["cmd"], stdout=logf, stderr=logf, stdin=subprocess.DEVNULL,
                           start_new_session=True)
    print(f"Started {svc['name']} (PID {proc.pid}) on port {svc['port']}")
    return proc

# Start all services
for svc in SRVICES:
    start_service(svc)
    time.sleep(5)

# Wait for all to be ready
for svc in SRVICES:
    for _ in range(15):
        if is_alive(svc["port"]):
            print(f"{svc['name']} ready")
            break
        time.sleep(1)

print("All services started. Daemon keeping alive...")
print("PID:", os.getpid())

# Keep alive forever — restart if any dies
while True:
    for svc in SRVICES:
        if not is_alive(svc["port"]):
            print(f"{svc['name']} died, restarting...")
            start_service(svc)
    time.sleep(10)

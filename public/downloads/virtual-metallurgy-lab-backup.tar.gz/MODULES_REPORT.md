# Heat Treatment · Sensitivity · Failure Modules

> Detailed technical documentation for three engineering-analysis modules of the
> Virtual Metallurgy Lab: the **Heat Treatment Simulation & Optimization
> Framework**, the **Sensitivity design-space mapper**, and the **Failure
> analysis (fracture mechanics) module**.

---

## Table of Contents

1. [Heat Treatment Module](#1-heat-treatment-module)
2. [Sensitivity Module](#2-sensitivity-module)
3. [Failure Module](#3-failure-module)
4. [How the Three Modules Connect](#4-how-the-three-modules-connect)

---

## 1. Heat Treatment Module

### Overview

The Heat Treatment module is a full **multi-step heat-treatment pipeline
simulator** with CALPHAD thermodynamics, kinetic modeling, property prediction,
process optimization, and ML surrogates. It uses a hybrid architecture: a
Python FastAPI backend (port 8001) for heavy computation, with a TypeScript
fallback simulation in the Next.js API routes for resilience.

**Location:**
- Frontend tab: `src/components/lab/tabs/heat-treatment-tab.tsx` (~2,580 lines)
- Backend service: `mini-services/heat-treatment-service/` (11 Python files, ~3,260 lines)
- API routes: `src/app/api/ht/` (8 routes with TS fallbacks)
- Shared types: `src/lib/heat-treatment-types.ts`
- Backend port: 8001 (FastAPI), with TS fallback in Next.js API routes

### Architecture

The module uses a **resilient hybrid architecture**:

1. **Primary path**: Next.js API routes proxy to the Python FastAPI service on
   port 8001, which calls pycalphad (port 8000) for real CALPHAD equilibrium
   calculations.
2. **Fallback path**: If the Python service is unreachable (3s timeout), the
   Next.js API routes compute results directly in TypeScript using the existing
   `metallurgy.ts` surrogate library — ensuring the tab always works.

```
Frontend Tab (heat-treatment-tab.tsx)
    │
    ├── LEFT (3/12): Alloy card + Step Editor (11 process types, 8 cooling methods)
    ├── CENTER (6/12): Workflow Pipeline + T-t curve + TTT/CCT diagram
    └── RIGHT (3/12): Results (4 sub-tabs) + Optimization panel
    │
    ▼ POST /api/ht/run?XTransformPort=8001
    │
Next.js API Route (run/route.ts)
    │
    ├── Try Python backend (port 8001) ──→ pycalphad (port 8000)
    │        │
    │        └── Real CALPHAD equilibrium + JMAK kinetics + Hall-Petch
    │
    └── TS Fallback (metallurgy.ts)
             │
             └── Regular-solution Gibbs + surrogate grain size + Hall-Petch
```

### Workflow Engine

Users build arbitrary multi-step pipelines. Each step supports:

| Parameter | Values |
|---|---|
| `process` | Austenitize, Temper, Solution Treat, Age Hardening, Stress Relief, Normalizing, Quenching, Annealing, Austempering, Martempering, Custom |
| `target_temp_c` | 25–1600 °C |
| `heating_rate` | K/min |
| `holding_time_min` | soak time, minutes |
| `cooling_method` | water_quench, oil_quench, polymer_quench, air_cool, furnace_cool, gas_quench, salt_bath, controlled |
| `atmosphere` | air, argon, nitrogen, vacuum, endothermic, exothermic, hydrogen, salt |
| `cycles` | repeat count |

Cooling rates by method (K/min): water_quench=6000, oil_quench=1500, polymer_quench=3000,
gas_quench=600, air_cool=60, furnace_cool=6, salt_bath=300.

### Kinetic Engine

#### Critical temperatures (Fe-C family)
- **A1** = 727 °C (eutectoid)
- **A3** = 910 − 200·C − 30·Mn − 11·Cr − 20·Ni − 50·Mo − 60·Si
- **Ms** (Andrews) = 539 − 423·C − 30.4·Mn − 17.7·Ni − 12.1·Cr − 7.5·Mo − 7.5·Si
- **Mf** = Ms − 215

#### Phase transformation logic
| Cooling rate | Dominant phase | Model |
|---|---|---|
| > 50 K/s | Martensite | fraction = 0.6 + R·0.004 (capped at 0.98) |
| 5–50 K/s | Ferrite + Pearlite | JMAK |
| < 5 K/s | Ferrite + Pearlite (coarse) | JMAK |

#### Grain growth
Parabolic Arrhenius: `d² = d₀² + K₀·exp(−Q/RT)·t`
- Fe: Q=280 kJ/mol, Al: Q=140 kJ/mol, Ni: Q=320 kJ/mol

### Property Prediction

| Property | Model |
|---|---|
| Yield strength | σ_y = σ₀ + k_HP·d⁻⁰·⁵ + σ_ss + σ_precip |
| UTS | 1.15·σ_y (Fe), 1.25·σ_y (Al), 1.10·σ_y (Ni) |
| Hardness (HRC) | σ_y/3.3 − 20 |
| Elongation | 30 − 0.025·σ_y (floor 5%) |
| Toughness | 200·exp(−0.06·(HRC−20)) |
| Fatigue | 0.45·UTS (ferrous), 0.35·UTS (non-ferrous) |

Hall-Petch k_HP: Fe=0.45, Al=0.07, Ni=0.3 MPa·m⁰·⁵

Tempering follows the **Hollomon-Jaffe parameter**: HJP = T_K·(20 + log₁₀(t_hr)).

### Optimization Engine

| Method | Implementation |
|---|---|
| Bayesian | GP surrogate + Expected Improvement |
| Genetic Algorithm | Population 20, 10 generations, tournament selection, SBX crossover |
| Random | Latin-hypercube with elite memory |
| Grid | Exhaustive grid |
| NSGA-II | Non-dominated sort + crowding distance for multi-objective Pareto |

### ML Surrogate

RandomForest, GradientBoosting, MLP (sklearn) trained on 300 Latin-hypercube
samples. Features: composition + workflow params. Targets: yield, UTS, hardness,
elongation, toughness. Typical R² ≈ 0.95.

### Presets (8 total)

| Preset | Alloy | Description |
|---|---|---|
| Quench & Temper (AISI 1040) | Fe-C | Austenitize 850°C → water quench → temper 550°C |
| Normalize (AISI 1045) | Fe-C | Austenitize 870°C → air cool |
| Age Hardening (Al-4Cu) | Al-Cu | Solution 540°C → quench → age 190°C |
| Solution Treat (Al-7Si) | Al-Si | Solution 540°C → age 165°C |
| Stress Relief (AISI 1020) | Fe-C | 595°C → furnace cool |
| Dual Treatment (Ni-Cr-Co) | Ni-Cr-Co | Solution 1080°C → age 850°C |

### Frontend Tab Behaviors

- **Auto-run on first visit**: loads an alloy-matched preset and runs the
  simulation automatically — users always see populated results immediately.
- **Auto-load TTT** on mount and when alloy changes.
- **Pretty phase names**: raw keys → proper labels (α-Al, θ-Al₂Cu, Martensite, etc.)
- **Uncertainty bars** on mechanical property cards (±1σ, 12-sample Monte Carlo).
- **Pareto front** scatter for multi-objective optimization.
- **Apply Best Workflow** button.
- **Persistence**: workflow + results + optimization result saved to localStorage.

### API Reference

| Route | Method | Purpose |
|---|---|---|
| `/api/ht/health` | GET | Service health (TS fallback always returns ok) |
| `/api/ht/presets` | GET | 8 preset workflows |
| `/api/ht/databases` | GET | CALPHAD databases |
| `/api/ht/run` | POST | Full simulation with uncertainty |
| `/api/ht/ttt` | POST | TTT diagram |
| `/api/ht/cct` | POST | CCT diagram |
| `/api/ht/optimize` | POST | Process optimization |
| `/api/ht/predict` | POST | ML surrogate prediction |

All routes try the Python backend first (3s timeout), then fall back to
TypeScript computation.

---

## 2. Sensitivity Module

### Overview

The Sensitivity module maps the **yield-strength design space** across a 2-D
grid of composition × cooling rate, at a user-selected ageing temperature.

**Location:**
- Frontend tab: `src/components/lab/tabs/sensitivity-tab.tsx` (394 lines)
- API route: `src/app/api/sensitivity/route.ts` (107 lines)

### The Design-Space Grid

A **24 × 28 grid**:
- 24 composition steps (linear, 0.5 wt% to xMax)
- 28 cooling-rate steps (logarithmic, 0.5 to 120 K/s)

For each cell, the route computes yield strength and UTS using:
```typescript
const grain = grainSize(x, R);           // µm
const hp = hallPetch(grain);             // Hall-Petch MPa
const ppt = precipitateDensity(x, H, R); // precipitates / µm³
const yld = 280 + 180*x + 0.018*ppt + (hp-40) - 1.6*grain;
```

### Visualisation

1. **KPI cards** — min σ_y, max σ_y, dynamic range
2. **Heatmap** — custom SVG 24×28 grid, copper→amber→emerald gradient
3. **σ_y vs Cooling Rate** — log-x line chart
4. **σ_y vs Composition** — line chart with reference dot

---

## 3. Failure Module

### Overview

The Failure module performs **predictive fracture-mechanics analysis** under
cyclic load: fatigue life, critical flaw size, failure mode, safety factors.

**Location:**
- Frontend tab: `src/components/lab/tabs/failure-tab.tsx` (467 lines)
- API route: `src/app/api/failure/route.ts` (158 lines)

### Fracture Mechanics Model

1. **Fracture toughness**: K_Ic = (Fe-C ? 80 : 30) + grain·0.15 + (1−x)·5
2. **Critical flaw size**: a_c = (K_Ic / (Y·Δσ·√π))²  (Y=1.12, edge crack)

### Paris-Law Crack Growth

```
da/dN = C · (ΔK)^m
ΔK = Y · Δσ · √(π·a)
N_f = ∫_{a₀}^{a_c} da / [C·(Y·Δσ·√(πa))^m]
```

| Alloy | C | m |
|---|---|---|
| Fe-C | 1.2×10⁻¹¹ | 3.2 |
| Al / Ni | 1.5×10⁻¹¹ | 3.2 |

### Failure-Mode Classification

| K_Ic / σ_y | Mode | Probabilities |
|---|---|---|
| < 0.25 | Brittle | Brittle 62%, Ductile 8%, Fatigue 30% |
| 0.25–0.6 | Mixed | Brittle 30%, Ductile 35%, Fatigue 35% |
| > 0.6 | Ductile | Brittle 10%, Ductile 55%, Fatigue 35% |

### Safety Factors

| Factor | Formula | Threshold |
|---|---|---|
| n_yield | σ_y / Δσ | >1.5 safe, 1.0–1.5 marginal, <1.0 fail |
| n_fracture | K_Ic / (Y·Δσ·√(π·a₀)) | same |

### Visualisation

1. **Load & Flaw sliders** — Δσ (20–400 MPa), a₀ (0.01–5 mm), R (−1 to 0.9)
2. **KPI cards** — N_f, a_c, n_fracture
3. **Failure-mode banner** — colored badge + probability bars + K_Ic readout
4. **Paris-law curve** — da/dN vs ΔK (log-y)
5. **Crack length vs cycles** — area chart with a_c and N_f reference lines
6. **Failure-mode map** — toughness-ratio × stress-ratio SVG with zones

---

## 4. How the Three Modules Connect

All three share the **same Zustand lab-store** (alloy system, composition,
cooling rate, heat-treatment temperature):

```
Lab Store (alloySystem, soluteFraction, coolingRateKs, heatTreatmentC)
    │
    ├── Sensitivity tab: sweeps comp × cooling-rate grid
    │
    ├── Heat Treatment tab: builds multi-step workflow, runs simulation
    │       └── final microstructure + mechanical properties
    │
    └── Failure tab: takes final properties, predicts fatigue life
```

**Typical workflow**:
1. **Sensitivity** — find a (composition, cooling rate) window for target yield
2. **Heat Treatment** — design the multi-step process, optimize parameters
3. **Failure** — verify fatigue life and safety factors for service loads

---

*End of document.*

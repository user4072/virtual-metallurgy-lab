/**
 * POST /api/ht/ttt
 * TTT diagram. Tries Python backend first; falls back to TS computation.
 */
import { NextRequest, NextResponse } from "next/server";
import { ALLOY_SYSTEMS, type AlloySystemId } from "@/lib/metallurgy";

export const runtime = "nodejs";
const UPSTREAM = "http://localhost:8001/ttt";

export async function POST(req: NextRequest) {
  const body = await req.json();
  // Try Python backend
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 3_000);
    const res = await fetch(UPSTREAM, { method: "POST", signal: ctrl.signal, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), cache: "no-store" });
    clearTimeout(t);
    if (res.ok) { const j = await res.json(); if (j?.ok) return NextResponse.json(j); }
  } catch { /* fallback */ }

  // TS fallback
  const sysId = (body.alloy?.system ?? "Al-Cu") as AlloySystemId;
  const comp = body.alloy?.composition ?? {};
  const C = (comp["C"] ?? 0.4) as number;
  const Mn = (comp["Mn"] ?? 0) as number;
  const Si = (comp["Si"] ?? 0) as number;
  const Ni = (comp["Ni"] ?? 0) as number;
  const Cr = (comp["Cr"] ?? 0) as number;
  const Mo = (comp["Mo"] ?? 0) as number;

  // Andrews formula for Ms
  const Ms = sysId === "Fe-C" ? Math.max(80, 539 - 423 * C - 30.4 * Mn - 17.7 * Ni - 12.1 * Cr - 7.5 * Mo - 7.5 * Si) : 200;
  const Mf = Ms - 215;
  const A1 = sysId === "Fe-C" ? 727 : 548;
  const A3 = sysId === "Fe-C" ? Math.max(727, 910 - 200 * C - 30 * Mn - 20 * Ni - 11 * Cr - 50 * Mo - 60 * Si) : 548;

  // Generate C-curves (nose at mid-temperature, parabolic shape on log-time)
  const cCurve = (Tlo: number, Thi: number, tNose: number, tWidth: number, n = 20) => {
    const pts: number[][] = [];
    for (let i = 0; i <= n; i++) {
      const T = Tlo + ((Thi - Tlo) * i) / n;
      const Tnose = (Tlo + Thi) / 2;
      const dt = Math.abs(T - Tnose) / Math.max(1, (Thi - Tlo) / 2);
      const t = tNose * Math.exp(dt * dt * Math.log(tWidth / tNose + 1));
      pts.push([Math.round(t * 100) / 100, Math.round(T)]);
    }
    return pts;
  };

  const curves: Record<string, number[][]> = {};
  if (sysId === "Fe-C") {
    curves.ferrite_start = cCurve(A1 + 20, A3 - 20, 10, 1e5);
    curves.ferrite_finish = cCurve(A1 + 20, A3 - 20, 50, 1e6);
    curves.pearlite_start = cCurve(A1 - 50, A1 + 20, 5, 1e4);
    curves.pearlite_finish = cCurve(A1 - 50, A1 + 20, 25, 1e5);
    curves.bainite_start = cCurve(Math.max(250, Ms), A1 - 30, 20, 1e5);
    curves.bainite_finish = cCurve(Math.max(250, Ms), A1 - 30, 80, 1e6);
    curves.martensite_start = [[0.01, Math.round(Ms)], [1e5, Math.round(Ms)]];
    curves.martensite_finish = [[0.01, Math.round(Mf)], [1e5, Math.round(Mf)]];
  } else {
    // For Al alloys — precipitation C-curves
    const solvus = sysId === "Al-Cu" ? 548 : sysId === "Al-Si" ? 577 : 1100;
    curves.precipitate_start = cCurve(100, solvus - 20, 60, 1e5);
    curves.precipitate_finish = cCurve(100, solvus - 20, 300, 1e6);
  }

  return NextResponse.json({ ok: true, curves, Ms_C: Math.round(Ms), Mf_C: Math.round(Mf), A1_C: A1, A3_C: Math.round(A3) });
}

/**
 * POST /api/ht/cct
 * CCT diagram. Tries Python backend first; falls back to TTT (shifted right).
 */
import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
const UPSTREAM = "http://localhost:8001/cct";

export async function POST(req: NextRequest) {
  const body = await req.json();
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 3_000);
    const res = await fetch(UPSTREAM, { method: "POST", signal: ctrl.signal, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), cache: "no-store" });
    clearTimeout(t);
    if (res.ok) { const j = await res.json(); if (j?.ok) return NextResponse.json(j); }
  } catch { /* fallback */ }

  // Fallback: call our own TTT route and shift curves right by 2×
  const tttRes = await fetch("http://localhost:3000/api/ht/ttt?XTransformPort=8001", {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
  });
  const ttt = await tttRes.json();
  if (!ttt?.ok) return NextResponse.json(ttt);

  // Shift all curves rightward (longer times) for CCT
  const shiftedCurves: Record<string, number[][]> = {};
  for (const [key, pts] of Object.entries(ttt.curves as Record<string, number[][]>)) {
    shiftedCurves[key] = pts.map(([t, T]) => [t * 2.5, T]);
  }
  return NextResponse.json({ ...ttt, curves: shiftedCurves });
}

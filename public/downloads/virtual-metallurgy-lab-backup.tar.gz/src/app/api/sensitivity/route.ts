/**
 * POST /api/sensitivity
 * -----------------------------------------------------------------------------
 * Sweeps the predicted yield strength (and UTS, elongation) across a grid of
 * (composition × cooling-rate) for the current alloy system, returning the
 * full matrix for heatmap + line-chart visualisation. This is the
 * "design-space map" a metallurgist uses to pick a processing window.
 */
import { NextRequest, NextResponse } from "next/server";
import {
  ALLOY_SYSTEMS,
  grainSize,
  hallPetch,
  precipitateDensity,
  stressStrainCurve,
  type AlloySystemId,
} from "@/lib/metallurgy";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      alloySystem?: AlloySystemId;
      heatTreatmentC?: number;
    };
    const sysId = (body.alloySystem ?? "Al-Cu") as AlloySystemId;
    const sys = ALLOY_SYSTEMS[sysId] ?? ALLOY_SYSTEMS["Al-Cu"];
    const H = Math.min(Math.max(Number(body.heatTreatmentC ?? 190), 20), 1400);

    const nC = 24; // composition steps
    const nR = 28; // cooling-rate steps (log)
    const xMin = 0.005;
    const xMax = sys.xMax;
    const rMin = 0.5;
    const rMax = 120;

    const xs: number[] = [];
    for (let i = 0; i < nC; i++) xs.push(xMin + ((xMax - xMin) * i) / (nC - 1));
    const rs: number[] = [];
    const lMin = Math.log10(rMin);
    const lMax = Math.log10(rMax);
    for (let j = 0; j < nR; j++) rs.push(Math.pow(10, lMin + ((lMax - lMin) * j) / (nR - 1)));

    // build matrix
    const matrix: number[][] = []; // [iC][iR] = yield
    const utsMatrix: number[][] = [];
    for (let i = 0; i < nC; i++) {
      const row: number[] = [];
      const utsRow: number[] = [];
      for (let j = 0; j < nR; j++) {
        const x = xs[i];
        const R = rs[j];
        const grain = grainSize(x, R);
        const hp = hallPetch(grain);
        const ppt = precipitateDensity(x, H, R);
        const solid = 180 * x;
        const orowan = 0.018 * ppt;
        const yld = Math.max(60, 280 + solid + orowan + (hp - 40) - 1.6 * grain);
        const ss = stressStrainCurve(yld, grain, x);
        row.push(+yld.toFixed(1));
        utsRow.push(+ss.ultimate.toFixed(1));
      }
      matrix.push(row);
      utsMatrix.push(utsRow);
    }

    // 1-D sweep vs R at the current composition (use midpoint x for the line chart)
    const midX = xs[Math.floor(nC / 2)];
    const sweepR = rs.map((R) => {
      const grain = grainSize(midX, R);
      const hp = hallPetch(grain);
      const ppt = precipitateDensity(midX, H, R);
      const yld = Math.max(60, 280 + 180 * midX + 0.018 * ppt + (hp - 40) - 1.6 * grain);
      return { R: +R.toFixed(2), yield: +yld.toFixed(1), grain: +grain.toFixed(2), ppt: +ppt.toFixed(0) };
    });

    // 1-D sweep vs X at the midpoint R
    const midR = rs[Math.floor(nR / 2)];
    const sweepX = xs.map((x) => {
      const grain = grainSize(x, midR);
      const hp = hallPetch(grain);
      const ppt = precipitateDensity(x, H, midR);
      const yld = Math.max(60, 280 + 180 * x + 0.018 * ppt + (hp - 40) - 1.6 * grain);
      return { x: +x.toFixed(4), yield: +yld.toFixed(1), ppt: +ppt.toFixed(0) };
    });

    return NextResponse.json({
      ok: true,
      alloySystem: sys.id,
      heatTreatmentC: H,
      compositionAxis: xs.map((x) => +x.toFixed(4)),
      coolingRateAxis: rs.map((r) => +r.toFixed(2)),
      yieldMatrix: matrix,
      utsMatrix,
      sweepR,
      sweepX,
      midpoint: { x: midX, R: midR },
      ranges: { xMin, xMax, rMin, rMax },
    });
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: e instanceof Error ? e.message : "unknown" },
      { status: 500 },
    );
  }
}

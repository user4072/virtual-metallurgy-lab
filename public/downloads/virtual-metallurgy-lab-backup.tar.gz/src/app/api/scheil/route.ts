/**
 * POST /api/scheil
 * Scheil-Gulliver non-equilibrium solidification simulation.
 */
import { NextRequest, NextResponse } from "next/server";
import {
  ALLOY_SYSTEMS,
  scheilSolidification,
  type AlloySystemId,
} from "@/lib/metallurgy";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      alloySystem?: AlloySystemId;
      soluteFraction?: number;
    };
    const sysId = (body.alloySystem ?? "Al-Cu") as AlloySystemId;
    const sys = ALLOY_SYSTEMS[sysId] ?? ALLOY_SYSTEMS["Al-Cu"];
    const x = Math.min(Math.max(Number(body.soluteFraction ?? 0.04), 0), sys.xMax);

    const res = scheilSolidification(sys, x, 80);
    return NextResponse.json({
      ok: true,
      alloySystem: sys.id,
      composition: x,
      ...res,
      points: res.points.map((p) => ({
        T: +p.T.toFixed(2),
        fs: +p.fs.toFixed(4),
        fl: +p.fl.toFixed(4),
        xL: +p.xL.toFixed(4),
        xS: +p.xS.toFixed(4),
        phase: p.phase,
      })),
    });
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: e instanceof Error ? e.message : "unknown" },
      { status: 500 },
    );
  }
}

/**
 * POST /api/causal_effect
 * -----------------------------------------------------------------------------
 * Estimates the Average Treatment Effect (ATE) of increasing the cooling rate
 * on the final yield strength, using a DoWhy-style backdoor analysis over a
 * linear structural causal model. Mirrors `causal_analyzer.py /estimate_ate`.
 */
import { NextRequest, NextResponse } from "next/server";
import { estimateATE, CAUSAL_NODES, CAUSAL_EDGES } from "@/lib/causal";

export const runtime = "nodejs";

interface CausalBody {
  coolingRateDelta?: number; // ΔR in K/s
  sampleSize?: number;
  seed?: number;
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Partial<CausalBody>;
    const deltaR = Number(body.coolingRateDelta ?? 10);
    const n = Math.min(Math.max(Number(body.sampleSize ?? 2000), 200), 20000);
    const seed = Number(body.seed ?? 42);

    const result = estimateATE(deltaR, n, seed);

    return NextResponse.json({
      ok: true,
      treatment: "Cooling Rate (R)",
      outcome: "Yield Strength (Y)",
      deltaR,
      ...result,
      graph: {
        nodes: CAUSAL_NODES.map((n2) => ({
          id: n2.id,
          label: n2.label,
          symbol: n2.symbol,
          kind: n2.kind,
          unit: n2.unit,
          x: n2.x,
          y: n2.y,
          description: n2.description,
        })),
        edges: CAUSAL_EDGES.map((e) => ({
          from: e.from,
          to: e.to,
          coefficient: e.coefficient,
          label: e.label,
        })),
      },
    });
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: e instanceof Error ? e.message : "unknown error" },
      { status: 500 },
    );
  }
}

/**
 * GET /api/references
 * Returns the curated literature reference micrographs + concept sources.
 */
import { NextResponse } from "next/server";
import {
  REFERENCE_MICROGRAPHS,
  CONCEPT_SOURCES,
} from "@/lib/references";

export const runtime = "nodejs";

export async function GET() {
  return NextResponse.json({
    ok: true,
    micrographs: REFERENCE_MICROGRAPHS,
    concepts: CONCEPT_SOURCES,
  });
}

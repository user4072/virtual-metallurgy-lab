/**
 * lab-store.ts
 * -----------------------------------------------------------------------------
 * Zustand store holding the global "lab session" state: selected alloy system,
 * composition, temperature, heat-treatment & cooling-rate parameters, and the
 * diffusion sampling settings. Components subscribe to slices of this store so
 * the sidebar and every tab stay in sync.
 *
 * Also holds the Heat-Treatment-Framework state: an editable workflow of HTStep
 * objects, the cached HT results + optimization result, and the Fe-C alloying
 * element weight fractions (Ni, Cr, Mn, Si, Mo). These are persisted to
 * localStorage and hydrated client-side via hydrateHtWorkflow().
 * -----------------------------------------------------------------------------
 */

import { create } from "zustand";
import type { AlloySystemId } from "@/lib/metallurgy";
import {
  DEFAULT_HT_WORKFLOW,
  makeDefaultStep,
  type HTOptimizationResult,
  type HTResults,
  type HTStep,
} from "@/lib/heat-treatment-types";

// ---- localStorage keys ----------------------------------------------------
const LS_HT_WORKFLOW = "vml-ht-v1";
const LS_HT_RESULTS = "vml-ht-results-v1";
const LS_HT_OPT = "vml-ht-opt-v1";

export interface LabState {
  // --- Material & composition ---------------------------------------------
  alloySystem: AlloySystemId;
  /** Solute weight fraction (e.g. Cu in Al-Cu, Cr in Ni-Cr-Co). Solvent = 1 - soluteFraction - soluteFraction2. */
  soluteFraction: number;
  /** Second solute weight fraction (e.g. Co in Ni-Cr-Co). Only used for ternary systems. */
  soluteFraction2: number;
  temperatureC: number; // service / inspection temperature
  heatTreatmentC: number; // ageing / solutionising temperature
  coolingRateKs: number; // K/s
  magnification: number; // SEM magnification x

  // --- Fe-C alloying elements (wt%) — used by HT tab ----------------------
  niWt: number;
  crWt: number;
  mnWt: number;
  siWt: number;
  moWt: number;

  // --- Surrogate model selection ------------------------------------------
  surrogateModel: "tabular-mlp" | "graph-gnn" | "ensemble";

  // --- Diffusion sampler ---------------------------------------------------
  diffusionSteps: number;
  guidanceScale: number;

  // --- Heat-treatment state (persisted) -----------------------------------
  htWorkflow: HTStep[];
  htSelectedStepId: string | null;
  htResults: HTResults | null;
  htOptimizationResult: HTOptimizationResult | null;

  // setters
  setAlloySystem: (s: AlloySystemId) => void;
  setSoluteFraction: (v: number) => void;
  setSoluteFraction2: (v: number) => void;
  setTemperatureC: (v: number) => void;
  setHeatTreatmentC: (v: number) => void;
  setCoolingRateKs: (v: number) => void;
  setMagnification: (v: number) => void;
  setSurrogateModel: (m: LabState["surrogateModel"]) => void;
  setDiffusionSteps: (v: number) => void;
  setGuidanceScale: (v: number) => void;

  // Fe-C alloying setters
  setNiWt: (v: number) => void;
  setCrWt: (v: number) => void;
  setMnWt: (v: number) => void;
  setSiWt: (v: number) => void;
  setMoWt: (v: number) => void;

  // HT actions
  setHtWorkflow: (steps: HTStep[]) => void;
  addHtStep: (step?: HTStep) => void;
  updateHtStep: (id: string, patch: Partial<HTStep>) => void;
  removeHtStep: (id: string) => void;
  moveHtStep: (id: string, direction: "up" | "down") => void;
  selectHtStep: (id: string | null) => void;
  setHtResults: (r: HTResults | null) => void;
  setHtOptimizationResult: (r: HTOptimizationResult | null) => void;
}

function persistHtWorkflow(steps: HTStep[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(LS_HT_WORKFLOW, JSON.stringify(steps));
  } catch {
    /* ignore quota errors */
  }
}
function persistHtResults(r: HTResults | null) {
  if (typeof window === "undefined") return;
  try {
    if (r) window.localStorage.setItem(LS_HT_RESULTS, JSON.stringify(r));
    else window.localStorage.removeItem(LS_HT_RESULTS);
  } catch {
    /* ignore */
  }
}
function persistHtOpt(r: HTOptimizationResult | null) {
  if (typeof window === "undefined") return;
  try {
    if (r) window.localStorage.setItem(LS_HT_OPT, JSON.stringify(r));
    else window.localStorage.removeItem(LS_HT_OPT);
  } catch {
    /* ignore */
  }
}

export const useLabStore = create<LabState>((set, get) => ({
  alloySystem: "Al-Cu",
  soluteFraction: 0.04,
  soluteFraction2: 0.10, // default Co fraction for Ni-Cr-Co
  temperatureC: 25,
  heatTreatmentC: 190,
  coolingRateKs: 8,
  magnification: 2500,

  // Default Fe-C alloying — matches AISI 1040 plain carbon steel.
  niWt: 0,
  crWt: 0,
  mnWt: 0.75,
  siWt: 0.25,
  moWt: 0,

  surrogateModel: "graph-gnn",
  diffusionSteps: 50,
  guidanceScale: 7.5,

  htWorkflow: DEFAULT_HT_WORKFLOW,
  htSelectedStepId: DEFAULT_HT_WORKFLOW[0]?.id ?? null,
  htResults: null,
  htOptimizationResult: null,

  setAlloySystem: (s) => set({ alloySystem: s }),
  setSoluteFraction: (v) => set({ soluteFraction: v }),
  setSoluteFraction2: (v) => set({ soluteFraction2: v }),
  setTemperatureC: (v) => set({ temperatureC: v }),
  setHeatTreatmentC: (v) => set({ heatTreatmentC: v }),
  setCoolingRateKs: (v) => set({ coolingRateKs: v }),
  setMagnification: (v) => set({ magnification: v }),
  setSurrogateModel: (m) => set({ surrogateModel: m }),
  setDiffusionSteps: (v) => set({ diffusionSteps: v }),
  setGuidanceScale: (v) => set({ guidanceScale: v }),

  setNiWt: (v) => set({ niWt: v }),
  setCrWt: (v) => set({ crWt: v }),
  setMnWt: (v) => set({ mnWt: v }),
  setSiWt: (v) => set({ siWt: v }),
  setMoWt: (v) => set({ moWt: v }),

  setHtWorkflow: (steps) => {
    persistHtWorkflow(steps);
    set({ htWorkflow: steps });
  },
  addHtStep: (step) => {
    const prev = get().htWorkflow.at(-1);
    const newStep = step ?? makeDefaultStep(prev);
    const steps = [...get().htWorkflow, newStep];
    persistHtWorkflow(steps);
    set({ htWorkflow: steps, htSelectedStepId: newStep.id });
  },
  updateHtStep: (id, patch) => {
    const steps = get().htWorkflow.map((s) => (s.id === id ? { ...s, ...patch } : s));
    persistHtWorkflow(steps);
    set({ htWorkflow: steps });
  },
  removeHtStep: (id) => {
    const steps = get().htWorkflow.filter((s) => s.id !== id);
    persistHtWorkflow(steps);
    const sel = get().htSelectedStepId === id ? (steps[0]?.id ?? null) : get().htSelectedStepId;
    set({ htWorkflow: steps, htSelectedStepId: sel });
  },
  moveHtStep: (id, direction) => {
    const steps = [...get().htWorkflow];
    const idx = steps.findIndex((s) => s.id === id);
    if (idx < 0) return;
    const target = direction === "up" ? idx - 1 : idx + 1;
    if (target < 0 || target >= steps.length) return;
    [steps[idx], steps[target]] = [steps[target], steps[idx]];
    persistHtWorkflow(steps);
    set({ htWorkflow: steps });
  },
  selectHtStep: (id) => set({ htSelectedStepId: id }),
  setHtResults: (r) => {
    persistHtResults(r);
    set({ htResults: r });
  },
  setHtOptimizationResult: (r) => {
    persistHtOpt(r);
    set({ htOptimizationResult: r });
  },
}));

/**
 * Client-side hydration of the persisted HT state.
 *
 * Call this from the HeatTreatmentTab on mount (inside a useEffect) to
 * restore the workflow, the last results, and the last optimization result
 * from localStorage. Safe to call server-side — it no-ops there.
 */
export function hydrateHtWorkflow() {
  if (typeof window === "undefined") return;
  try {
    const raw = window.localStorage.getItem(LS_HT_WORKFLOW);
    if (raw) {
      const parsed = JSON.parse(raw) as HTStep[];
      if (Array.isArray(parsed) && parsed.length > 0) {
        useLabStore.setState((s) => ({
          htWorkflow: parsed,
          htSelectedStepId: s.htSelectedStepId && parsed.some((p) => p.id === s.htSelectedStepId) ? s.htSelectedStepId : parsed[0].id,
        }));
      }
    }
  } catch {
    /* malformed JSON — keep defaults */
  }
  try {
    const rawR = window.localStorage.getItem(LS_HT_RESULTS);
    if (rawR) {
      const parsed = JSON.parse(rawR) as HTResults;
      if (parsed && typeof parsed === "object") useLabStore.setState({ htResults: parsed });
    }
  } catch {
    /* ignore */
  }
  try {
    const rawO = window.localStorage.getItem(LS_HT_OPT);
    if (rawO) {
      const parsed = JSON.parse(rawO) as HTOptimizationResult;
      if (parsed && typeof parsed === "object") useLabStore.setState({ htOptimizationResult: parsed });
    }
  } catch {
    /* ignore */
  }
}

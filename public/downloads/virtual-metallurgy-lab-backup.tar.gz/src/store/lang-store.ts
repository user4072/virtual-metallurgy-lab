/**
 * lang-store.ts — Zustand store for the active UI language (en / fa).
 * Persists to localStorage so the choice survives reloads. When `fa` is
 * active, the document <html dir> flips to "rtl".
 */
import { create } from "zustand";
import { DICTS, type Lang, type Dict } from "@/lib/i18n";

interface LangState {
  lang: Lang;
  dict: Dict;
  setLang: (l: Lang) => void;
  toggle: () => void;
  hydrate: () => void;
}

const KEY = "vml-lang-v1";

function applyDir(lang: Lang) {
  if (typeof document !== "undefined") {
    document.documentElement.dir = lang === "fa" ? "rtl" : "ltr";
    document.documentElement.lang = lang;
  }
}

export const useLang = create<LangState>((set, get) => ({
  lang: "en",
  dict: DICTS.en,
  setLang: (l) => {
    applyDir(l);
    if (typeof window !== "undefined") {
      try { window.localStorage.setItem(KEY, l); } catch { /* */ }
    }
    set({ lang: l, dict: DICTS[l] });
  },
  toggle: () => {
    const next = get().lang === "en" ? "fa" : "en";
    get().setLang(next);
  },
  hydrate: () => {
    if (typeof window === "undefined") return;
    try {
      const saved = window.localStorage.getItem(KEY) as Lang | null;
      if (saved === "en" || saved === "fa") {
        applyDir(saved);
        set({ lang: saved, dict: DICTS[saved] });
      }
    } catch { /* */ }
  },
}));

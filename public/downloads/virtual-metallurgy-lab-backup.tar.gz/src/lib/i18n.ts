/**
 * i18n.ts
 * -----------------------------------------------------------------------------
 * Bilingual (English / Persian-Farsi) dictionary for the Virtual Metallurgy Lab.
 * Persian is the official language of Iran (فارسی). When `fa` is active, the
 * document direction switches to RTL (right-to-left).
 *
 * Keys are organised by component so the consumer can do t.header.title etc.
 * -----------------------------------------------------------------------------
 */

export type Lang = "en" | "fa";

export interface Dict {
  dir: "ltr" | "rtl";
  // ---- Header ----
  header: {
    subtitle: string;
    share: string;
    copied: string;
    shareToastTitle: string;
    shareToastDesc: string;
    clock: string; // IRST label
  };
  // ---- Page title strip ----
  page: {
    breadcrumb: { vml: string; session: string; dashboard: string };
    title: string;
    subtitle: string;
    modules: string;
    online: string;
  };
  // ---- Tab labels ----
  tabs: {
    overview: string;
    phase: string;
    micro: string;
    micro3d: string;
    scheil: string;
    mech: string;
    field: string;
    causal: string;
    opt: string;
    radar: string;
    compare: string;
    sens: string;
    fail: string;
    report: string;
    refs: string;
    arch: string;
    heat: string;
  };
  // ---- Sidebar ----
  sidebar: {
    materialParams: string;
    presets: string;
    // group labels
    groupMaterial: string;
    groupThermal: string;
    groupModels: string;
    // sections
    alloySystem: string;
    solvent: string;
    solute: string;
    meltSolvent: string;
    eutectic: string;
    composition: string;
    inspectionTemp: string;
    heatTreatment: string;
    coolingRate: string;
    airCool: string;
    oilQuench: string;
    water: string;
    magnification: string;
    surrogateModel: string;
    graphGnn: string;
    tabularMlp: string;
    ensemble: string;
    diffusionSampler: string;
    inferenceSteps: string;
    guidanceScale: string;
    session: string;
    live: string;
    // presets
    presetCategories: { all: string; wroughtAl: string; castAl: string; steel: string; stainless: string };
    // history
    history: string;
    historyEmpty: string;
    clear: string;
  };
  // ---- Footer ----
  footer: {
    tagline: string;
    inferenceOnDevice: string;
    docs: string;
    source: string;
  };
  // ---- Heat Treatment tab ----
  heat: {
    title: string;
    subtitle: string;
    // workflow + steps
    loadPreset: string;
    presetHint: string;
    addStep: string;
    stepName: string;
    stepEditor: string;
    process: string;
    targetTemp: string;
    heatingRate: string;
    holdingTime: string;
    atmosphere: string;
    pressure: string;
    coolingMethod: string;
    coolingRate: string;
    cycles: string;
    moveUp: string;
    moveDown: string;
    deleteStep: string;
    selectStep: string;
    pipeline: string;
    pipelineHint: string;
    // run / simulate
    runSimulation: string;
    running: string;
    reRun: string;
    // results
    results: string;
    noResults: string;
    noResultsHint: string;
    microstructure: string;
    mechanical: string;
    physical: string;
    history: string;
    grainSize: string;
    phaseFractions: string;
    dominantPhase: string;
    yieldStrength: string;
    uts: string;
    hardness: string;
    elongation: string;
    toughness: string;
    fatigue: string;
    density: string;
    thermalCond: string;
    elecCond: string;
    elasticMod: string;
    cte: string;
    uncertainty: string;
    processingHistory: string;
    totalTime: string;
    peakTemp: string;
    // diagrams
    tempTimeCurve: string;
    tttCct: string;
    showTtt: string;
    showCct: string;
    loadingTtt: string;
    tttError: string;
    // optimization
    optimization: string;
    objective: string;
    method: string;
    iterations: string;
    runOptimization: string;
    paretoFront: string;
    convergence: string;
    applyBest: string;
    appliedBest: string;
    bestParams: string;
    noOptResult: string;
    // alloy card
    alloy: string;
    alloySystem: string;
    alloyName: string;
    feCAlloying: string;
    ni: string;
    cr: string;
    mn: string;
    si: string;
    mo: string;
    // misc
    serviceDown: string;
    serviceDownHint: string;
    step: string;
    of: string;
    min: string;
    max: string;
    cyclesShort: string;
    autoRunHint: string;
  };
}

const en: Dict = {
  dir: "ltr",
  header: {
    subtitle: "AI-Driven Materials Simulation · Surrogate · Diffusion · Causal",
    share: "Share",
    copied: "Copied!",
    shareToastTitle: "Recipe link copied",
    shareToastDesc: "The full alloy recipe is now in your clipboard.",
    clock: "IRST",
  },
  page: {
    breadcrumb: { vml: "VML", session: "Session", dashboard: "Engineering Dashboard" },
    title: "Materials Engineering Dashboard",
    subtitle:
      "Surrogate · Scheil solidification · Mechanical & fatigue · Causal inference · Bayesian optimisation · Phase-field — real-time.",
    modules: "modules",
    online: "all engines online",
  },
  tabs: {
    overview: "Overview",
    phase: "Phase",
    micro: "Microstructure",
    micro3d: "3D Grains",
    scheil: "Solidification",
    mech: "Mechanical",
    field: "Phase-Field",
    causal: "Causal",
    opt: "Optimization",
    radar: "Property Radar",
    compare: "Compare",
    sens: "Sensitivity",
    fail: "Failure",
    report: "Report",
    refs: "References",
    arch: "Architecture",
    heat: "Heat Treatment",
  },
  sidebar: {
    materialParams: "Material Parameters",
    presets: "Alloy Presets",
    groupMaterial: "Material",
    groupThermal: "Thermal Processing",
    groupModels: "AI Models",
    alloySystem: "Alloy System",
    solvent: "Solvent",
    solute: "Solute",
    meltSolvent: "Tₘ (solvent)",
    eutectic: "T_eutectic",
    composition: "Composition",
    inspectionTemp: "Inspection Temp.",
    heatTreatment: "Heat-Treatment T",
    coolingRate: "Cooling Rate",
    airCool: "Air cool",
    oilQuench: "Oil quench",
    water: "Water",
    magnification: "SEM Magnification",
    surrogateModel: "Surrogate Model",
    graphGnn: "Graph GNN (PyG · GAT)",
    tabularMlp: "Tabular MLP",
    ensemble: "Ensemble (5× deep)",
    diffusionSampler: "Diffusion Sampler",
    inferenceSteps: "Inference steps",
    guidanceScale: "Guidance scale (CFG)",
    session: "session",
    live: "live",
    presetCategories: { all: "All", wroughtAl: "Wrought Al", castAl: "Cast Al", steel: "Steel", stainless: "Stainless" },
    history: "Session History",
    historyEmpty: "Adjust parameters to start logging explored alloys.",
    clear: "clear",
  },
  footer: {
    tagline: "AI-Driven Materials Simulation Platform · surrogate + diffusion + causal",
    inferenceOnDevice: "inference on-device",
    docs: "docs",
    source: "source",
  },
  heat: {
    title: "Heat Treatment Simulation & Optimization",
    subtitle: "Multi-step workflow · TTT/CCT diagrams · property prediction · Bayesian / GA optimization",
    loadPreset: "Load Preset",
    presetHint: "Matched to the current alloy system",
    addStep: "Add Step",
    stepName: "Step Name",
    stepEditor: "Step Editor",
    process: "Process",
    targetTemp: "Target Temp.",
    heatingRate: "Heating Rate",
    holdingTime: "Hold Time",
    atmosphere: "Atmosphere",
    pressure: "Pressure",
    coolingMethod: "Cooling Method",
    coolingRate: "Cooling Rate",
    cycles: "Cycles",
    moveUp: "Move Up",
    moveDown: "Move Down",
    deleteStep: "Delete Step",
    selectStep: "Select Step",
    pipeline: "Workflow Pipeline",
    pipelineHint: "Drag-free ordered list — click a node to edit it",
    runSimulation: "Run Simulation",
    running: "Running…",
    reRun: "Re-run Simulation",
    results: "Results",
    noResults: "No results yet",
    noResultsHint: "Click Run Simulation to compute the final microstructure and properties.",
    microstructure: "Microstructure",
    mechanical: "Mechanical",
    physical: "Physical",
    history: "History",
    grainSize: "Grain Size",
    phaseFractions: "Phase Fractions",
    dominantPhase: "Dominant Phase",
    yieldStrength: "Yield σ_y",
    uts: "UTS",
    hardness: "Hardness",
    elongation: "Elongation",
    toughness: "Toughness",
    fatigue: "Fatigue σ_e",
    density: "Density",
    thermalCond: "Thermal Cond.",
    elecCond: "Elec. Cond.",
    elasticMod: "Elastic Mod.",
    cte: "CTE",
    uncertainty: "Uncertainty",
    processingHistory: "Processing History",
    totalTime: "Total Time",
    peakTemp: "Peak Temp.",
    tempTimeCurve: "Temperature–Time Curve",
    tttCct: "TTT / CCT Diagram",
    showTtt: "Show TTT",
    showCct: "Show CCT",
    loadingTtt: "Loading TTT diagram…",
    tttError: "Failed to load TTT diagram",
    optimization: "Process Optimization",
    objective: "Objective",
    method: "Method",
    iterations: "Iterations",
    runOptimization: "Run Optimization",
    paretoFront: "Pareto Front",
    convergence: "Convergence",
    applyBest: "Apply Best Workflow",
    appliedBest: "Workflow applied ✓",
    bestParams: "Best Parameters",
    noOptResult: "Run optimization to find the best process parameters.",
    alloy: "Alloy",
    alloySystem: "Alloy System",
    alloyName: "Alloy Name",
    feCAlloying: "Fe-C Alloying (wt%)",
    ni: "Ni",
    cr: "Cr",
    mn: "Mn",
    si: "Si",
    mo: "Mo",
    serviceDown: "Heat-treatment service unavailable",
    serviceDownHint: "Backend service on port 8001 is not running. The tab stays interactive; results and TTT/CCT are unavailable until it restarts.",
    step: "Step",
    of: "of",
    min: "min",
    max: "max",
    cyclesShort: "×",
    autoRunHint: "Auto-running initial simulation…",
  },
};

const fa: Dict = {
  dir: "rtl",
  header: {
    subtitle: "شبیه‌سازی مواد با هوش مصنوعی · جایگزین · نفوذ · علی",
    share: "اشتراک",
    copied: "کپی شد!",
    shareToastTitle: "لینک نسخه کپی شد",
    shareToastDesc: "نسخه کامل آلیاژ در کلیپ‌بورد شما قرار گرفت.",
    clock: "IRST",
  },
  page: {
    breadcrumb: { vml: "VML", session: "نشست", dashboard: "داشبورد مهندسی" },
    title: "داشبورد مهندسی مواد",
    subtitle:
      "جایگزین · انجماد شیل · مکانیک و خستگی · استنتاج علی · بهینه‌سازی بیزی · میدان فاز — بلادرنگ.",
    modules: "ماژول",
    online: "همه موتورها آنلاین",
  },
  tabs: {
    overview: "نمای کلی",
    phase: "فاز",
    micro: "ریزساختار",
    micro3d: "دانه‌های ۳بعدی",
    scheil: "انجماد",
    mech: "مکانیک",
    field: "میدان فاز",
    causal: "علی",
    opt: "بهینه‌سازی",
    radar: "رادار خواص",
    compare: "مقایسه",
    sens: "حساسیت",
    fail: "خرابی",
    report: "گزارش",
    refs: "مراجع",
    arch: "معماری",
    heat: "عملیات حرارتی",
  },
  sidebar: {
    materialParams: "پارامترهای ماده",
    presets: "نسخه‌های آلیاژ",
    groupMaterial: "ماده",
    groupThermal: "پردازش حرارتی",
    groupModels: "مدل‌های هوش مصنوعی",
    alloySystem: "سامانه آلیاژی",
    solvent: "حلال",
    solute: "حلال",
    meltSolvent: "Tₘ (حلال)",
    eutectic: "T_یوتکتیک",
    composition: "ترکیب",
    inspectionTemp: "دمای بازرسی",
    heatTreatment: "دمای عمل حرارتی",
    coolingRate: "نرخ سرد شدن",
    airCool: "سرد شدن هوا",
    oilQuench: "کوئنچ روغن",
    water: "آب",
    magnification: "بزرگنمایی SEM",
    surrogateModel: "مدل جایگزین",
    graphGnn: "گراف GNN (PyG · GAT)",
    tabularMlp: "MLP جدولی",
    ensemble: "آنسامبل (۵× عمیق)",
    diffusionSampler: "نمونه‌گیر نفوذ",
    inferenceSteps: "مراحل استنتاج",
    guidanceScale: "مقیاس هدایت (CFG)",
    session: "نشست",
    live: "زنده",
    presetCategories: { all: "همه", wroughtAl: "آل کارخانه", castAl: "آل ریخته", steel: "فولاد", stainless: "زنگ‌نزن" },
    history: "تاریخچه نشست",
    historyEmpty: "پارامترها را تنظیم کنید تا آلیاژهای کاوش شده ثبت شوند.",
    clear: "پاک کردن",
  },
  footer: {
    tagline: "پلتفرم شبیه‌سازی مواد با هوش مصنوعی · جایگزین + نفوذ + علی",
    inferenceOnDevice: "استنتاج روی دستگاه",
    docs: "مستندات",
    source: "منبع",
  },
  heat: {
    title: "شبیه‌سازی و بهینه‌سازی عملیات حرارتی",
    subtitle: "گردش‌کار چندمرحله‌ای · نمودارهای TTT/CCT · پیش‌بینی خواص · بهینه‌سازی بیزی/ژنتیک",
    loadPreset: "بارگذاری پیش‌تنظیم",
    presetHint: "منطبق با سامانه آلیاژی فعلی",
    addStep: "افزودن مرحله",
    stepName: "نام مرحله",
    stepEditor: "ویرایشگر مرحله",
    process: "فرآیند",
    targetTemp: "دمای هدف",
    heatingRate: "نرخ گرمایش",
    holdingTime: "زمان نگهداری",
    atmosphere: "اتمسفر",
    pressure: "فشار",
    coolingMethod: "روش سرد کردن",
    coolingRate: "نرخ سرد کردن",
    cycles: "تعداد دور",
    moveUp: "بالا",
    moveDown: "پایین",
    deleteStep: "حذف مرحله",
    selectStep: "انتخاب مرحله",
    pipeline: "خط لوله گردش‌کار",
    pipelineHint: "فهرست مرتب — برای ویرایش روی یک گره کلیک کنید",
    runSimulation: "اجرای شبیه‌سازی",
    running: "در حال اجرا…",
    reRun: "اجرای مجدد",
    results: "نتایج",
    noResults: "هنوز نتیجه‌ای وجود ندارد",
    noResultsHint: "برای محاسبه ریزساختار و خواص نهایی، اجرای شبیه‌سازی را بزنید.",
    microstructure: "ریزساختار",
    mechanical: "مکانیکی",
    physical: "فیزیکی",
    history: "تاریخچه",
    grainSize: "اندازه دانه",
    phaseFractions: "کسر فازها",
    dominantPhase: "فاز غالب",
    yieldStrength: "تنش تسلیم σ_y",
    uts: "UTS",
    hardness: "سختی",
    elongation: "ازدیاد طول",
    toughness: "چقرمگی",
    fatigue: "خستگی σ_e",
    density: "چگالی",
    thermalCond: "رسانایی حرارتی",
    elecCond: "رسانایی الکتریکی",
    elasticMod: "مدول الاستیک",
    cte: "CTE",
    uncertainty: "عدم قطعیت",
    processingHistory: "تاریخچه پردازش",
    totalTime: "زمان کل",
    peakTemp: "دمای اوج",
    tempTimeCurve: "منحنی دما–زمان",
    tttCct: "نمودار TTT / CCT",
    showTtt: "نمایش TTT",
    showCct: "نمایش CCT",
    loadingTtt: "در حال بارگذاری نمودار TTT…",
    tttError: "بارگذاری نمودار TTT ناموفق بود",
    optimization: "بهینه‌سازی فرآیند",
    objective: "هدف",
    method: "روش",
    iterations: "تعداد تکرار",
    runOptimization: "اجرای بهینه‌سازی",
    paretoFront: "جبهه پارتو",
    convergence: "همگرایی",
    applyBest: "اعمال بهترین گردش‌کار",
    appliedBest: "گردش‌کار اعمال شد ✓",
    bestParams: "بهترین پارامترها",
    noOptResult: "برای یافتن بهترین پارامترهای فرآیند، بهینه‌سازی را اجرا کنید.",
    alloy: "آلیاژ",
    alloySystem: "سامانه آلیاژی",
    alloyName: "نام آلیاژ",
    feCAlloying: "عناصر آلیاژی Fe-C (wt%)",
    ni: "Ni",
    cr: "Cr",
    mn: "Mn",
    si: "Si",
    mo: "Mo",
    serviceDown: "سرویس عملیات حرارتی در دسترس نیست",
    serviceDownHint: "سرویس بک‌اند روی پورت 8001 در حال اجرا نیست. تب تعاملی باقی می‌ماند؛ نتایج و TTT/CCT تا زمان راه‌اندازی مجدد در دسترس نیستند.",
    step: "مرحله",
    of: "از",
    min: "حداقل",
    max: "حداکثر",
    cyclesShort: "×",
    autoRunHint: "اجرای خودکار شبیه‌سازی اولیه…",
  },
};

export const DICTS: Record<Lang, Dict> = { en, fa };

"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useCausalEffect } from "@/components/lab/use-lab-data";
import { CausalGraph } from "@/components/lab/causal-graph";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Cell,
  Tooltip,
  ResponsiveContainer,
  ErrorBar,
  CartesianGrid,
} from "recharts";
import {
  GitBranch,
  Activity,
  ShieldCheck,
  ShieldAlert,
  TrendingUp,
  Sigma,
  FlaskRound,
} from "lucide-react";

export function CausalTab() {
  const [deltaR, setDeltaR] = useState(10);
  const [sampleSize, setSampleSize] = useState(2000);

  const body = { coolingRateDelta: deltaR, sampleSize, seed: 42 };
  const { data, loading, error } = useCausalEffect(body, [deltaR, sampleSize]);

  return (
    <div className="space-y-5">
      {/* ATE control + headline */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="bg-card/60 backdrop-blur lg:col-span-1">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <FlaskRound className="h-4 w-4 text-primary" />
              Intervention Setup
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div>
              <div className="mb-2 flex items-center justify-between">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                  Δ Cooling rate (treatment)
                </span>
                <span className="rounded bg-primary/10 px-2 py-0.5 font-mono text-xs font-semibold tabular-nums text-primary">
                  +{deltaR} K/s
                </span>
              </div>
              <Slider
                value={[deltaR]}
                min={1}
                max={80}
                step={1}
                onValueChange={(v) => setDeltaR(v[0])}
              />
              <div className="mt-1 flex justify-between text-[9px] text-muted-foreground">
                <span>mild</span>
                <span>severe quench</span>
              </div>
            </div>
            <div>
              <div className="mb-2 flex items-center justify-between">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                  Observational sample n
                </span>
                <span className="rounded bg-emerald-500/10 px-2 py-0.5 font-mono text-xs font-semibold tabular-nums text-emerald-400">
                  {sampleSize.toLocaleString()}
                </span>
              </div>
              <Slider
                value={[sampleSize]}
                min={200}
                max={20000}
                step={100}
                onValueChange={(v) => setSampleSize(v[0])}
              />
            </div>
            <div className="rounded-md border border-border/40 bg-background/40 p-2.5 text-[10.5px] leading-relaxed text-muted-foreground">
              <span className="font-mono text-foreground/90">do(R := r + Δr)</span>{" "}
              — the Average Treatment Effect is estimated by forward-sampling the
              SCM under the intervention, then cross-checked with a backdoor
              linear regression on observational data.
            </div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden bg-card/60 backdrop-blur lg:col-span-2">
          <div className="absolute inset-0 grid-bg opacity-40" />
          <CardHeader className="relative pb-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Sigma className="h-4 w-4 text-primary" />
              Average Treatment Effect · E[Y | do(R+Δr)] − E[Y | do(R)]
            </CardTitle>
          </CardHeader>
          <CardContent className="relative">
            {!data ? (
              <Skeleton className="h-28 w-full" />
            ) : (
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                <Stat
                  label="ATE (Δσ_y)"
                  value={`${data.ate >= 0 ? "+" : ""}${data.ate.toFixed(1)}`}
                  unit="MPa"
                  accent
                  tone={data.ate >= 0 ? "emerald" : "rose"}
                />
                <Stat
                  label="Std. error"
                  value={`±${data.stdError.toFixed(1)}`}
                  unit="MPa"
                />
                <Stat
                  label="95% CI"
                  value={`[${data.ciLower.toFixed(0)}, ${data.ciUpper.toFixed(0)}]`}
                  unit="MPa"
                />
                <Stat
                  label="Δσ_y / ΔR"
                  value={`${(data.ate / deltaR).toFixed(2)}`}
                  unit="MPa·s/K"
                />
                <div className="col-span-2 flex items-center justify-between rounded-md border border-border/40 bg-background/40 px-3 py-2 sm:col-span-4">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-3.5 w-3.5 text-muted-foreground" />
                    <span className="text-[11px] text-muted-foreground">
                      Baseline σ_y
                    </span>
                    <span className="font-mono text-xs tabular-nums text-foreground">
                      {data.baselineY.toFixed(1)} MPa
                    </span>
                  </div>
                  <span className="font-mono text-muted-foreground">→</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-muted-foreground">
                      Treated σ_y
                    </span>
                    <span className="font-mono text-xs font-semibold tabular-nums text-primary">
                      {data.treatedY.toFixed(1)} MPa
                    </span>
                  </div>
                  <div className="hidden items-center gap-2 sm:flex">
                    <span className="text-[11px] text-muted-foreground">n</span>
                    <span className="font-mono text-xs tabular-nums">
                      {data.n.toLocaleString()}
                    </span>
                  </div>
                </div>
                <div className="col-span-2 font-mono text-[10px] leading-relaxed text-muted-foreground sm:col-span-4">
                  estimand: {data.estimand}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Graph + ATE bar + refuters */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-5">
        <Card className="bg-card/60 backdrop-blur xl:col-span-3">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm">
              <GitBranch className="h-4 w-4 text-cyan-400" />
              Causal DAG — Processing → Microstructure → Yield
            </CardTitle>
          </CardHeader>
          <CardContent className="pb-4">
            {!data ? (
              <Skeleton className="h-[360px] w-full" />
            ) : (
              <CausalGraph data={data} highlightTreatment="R" />
            )}
          </CardContent>
        </Card>

        <div className="space-y-4 xl:col-span-2">
          <Card className="bg-card/60 backdrop-blur">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-sm">
                <Activity className="h-4 w-4 text-emerald-400" />
                ATE with 95% CI
              </CardTitle>
            </CardHeader>
            <CardContent className="h-[180px]">
              {!data ? (
                <Skeleton className="h-full w-full" />
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      {
                        name: "Baseline",
                        ate: data.baselineY,
                        err: 0,
                      },
                      {
                        name: "Treated",
                        ate: data.treatedY,
                        err: data.stdError * 1.96,
                      },
                    ]}
                    layout="vertical"
                    margin={{ top: 8, right: 24, bottom: 8, left: 8 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      stroke="oklch(0.35 0.008 60 / 0.25)"
                      horizontal={false}
                    />
                    <XAxis
                      type="number"
                      tick={{ fill: "oklch(0.7 0.01 60)", fontSize: 10, fontFamily: "var(--font-geist-mono)" }}
                      stroke="oklch(0.4 0.008 60)"
                      label={{
                        value: "σ_y (MPa)",
                        position: "insideBottom",
                        offset: -2,
                        fill: "oklch(0.65 0.01 60)",
                        fontSize: 10,
                      }}
                    />
                    <YAxis
                      type="category"
                      dataKey="name"
                      tick={{ fill: "oklch(0.8 0.01 60)", fontSize: 11, fontFamily: "var(--font-geist-mono)" }}
                      stroke="oklch(0.4 0.008 60)"
                      width={64}
                    />
                    <Tooltip
                      cursor={{ fill: "oklch(0.78 0.15 55 / 0.08)" }}
                      contentStyle={{
                        background: "oklch(0.19 0.008 60)",
                        border: "1px solid oklch(0.35 0.008 60)",
                        borderRadius: 8,
                        fontSize: 11,
                        fontFamily: "var(--font-geist-mono)",
                      }}
                      formatter={(v: number) => [`${v.toFixed(1)} MPa`, "σ_y"]}
                    />
                    <Bar
                      dataKey="ate"
                      radius={[0, 4, 4, 0]}
                      isAnimationActive={false}
                    >
                      {["oklch(0.5 0.01 60)", "oklch(0.78 0.15 55)"].map((c, i) => (
                        <Cell key={i} fill={c} />
                      ))}
                      <ErrorBar
                        dataKey="err"
                        stroke="oklch(0.9 0 0)"
                        strokeWidth={1.2}
                        width={6}
                      />
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          <Card className="bg-card/60 backdrop-blur">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-sm">
                <ShieldCheck className="h-4 w-4 text-primary" />
                Robustness Refuters (DoWhy)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {!data
                ? [0, 1, 2].map((i) => <Skeleton key={i} className="h-9 w-full" />)
                : data.refuters.map((r) => (
                    <div
                      key={r.name}
                      className="flex items-center justify-between rounded-md border border-border/40 bg-background/40 px-3 py-2"
                    >
                      <div className="flex items-center gap-2">
                        {r.passed ? (
                          <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                        ) : (
                          <ShieldAlert className="h-3.5 w-3.5 text-amber-400" />
                        )}
                        <span className="text-xs">{r.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[10px] tabular-nums text-muted-foreground">
                          {r.newEstimate.toFixed(1)}
                        </span>
                        <Badge
                          variant="outline"
                          className={`text-[9px] ${r.passed ? "border-emerald-500/40 text-emerald-400" : "border-amber-500/40 text-amber-400"}`}
                        >
                          {r.passed ? "PASS" : "WARN"}
                        </Badge>
                      </div>
                    </div>
                  ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  unit,
  accent,
  tone,
}: {
  label: string;
  value: string;
  unit: string;
  accent?: boolean;
  tone?: "emerald" | "rose";
}) {
  const toneCls =
    tone === "emerald"
      ? "text-emerald-400"
      : tone === "rose"
        ? "text-rose-400"
        : "text-foreground";
  return (
    <div className="rounded-md border border-border/40 bg-background/40 p-3">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
      <div
        className={`mt-1 font-mono text-2xl font-semibold tabular-nums ${accent ? toneCls : "text-foreground"}`}
      >
        {value}
      </div>
      <div className="text-[10px] text-muted-foreground">{unit}</div>
    </div>
  );
}

"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  REFERENCE_MICROGRAPHS,
  CONCEPT_SOURCES,
  type ReferenceMicrograph,
} from "@/lib/references";
import {
  BookOpen,
  Image as ImageIcon,
  ExternalLink,
  Microscope,
  FlaskConical,
  Filter,
} from "lucide-react";

type Category = "all" | "dendritic" | "eutectic" | "pearlite-bainite" | "fracture";

const CATEGORIES: { id: Category; label: string }[] = [
  { id: "all", label: "All" },
  { id: "dendritic", label: "Al-Cu dendritic" },
  { id: "eutectic", label: "Al-Si eutectic" },
  { id: "pearlite-bainite", label: "Steel pearlite/bainite" },
  { id: "fracture", label: "Fractography" },
];

export function ReferencesTab() {
  const [cat, setCat] = useState<Category>("all");
  const [active, setActive] = useState<ReferenceMicrograph | null>(null);

  const filtered =
    cat === "all"
      ? REFERENCE_MICROGRAPHS
      : REFERENCE_MICROGRAPHS.filter((m) => m.category === cat);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="bg-card/60 backdrop-blur lg:col-span-1">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <BookOpen className="h-4 w-4 text-primary" />
              Literature Reference Library
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-[11.5px] leading-relaxed text-muted-foreground">
            <p>
              <span className="text-foreground/90">{REFERENCE_MICROGRAPHS.length} curated micrographs</span>{" "}
              sourced from peer-reviewed publications and reference atlases
              (Nature, Springer, ASM International, Cambridge University Press,
              QATM, Nanoscience Instruments). These are the ground-truth images a
              generative microstructure diffusion model is trained against, and
              the reference standards a metallurgist compares synthesised images
              to.
            </p>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <Stat label="Sources" value={new Set(REFERENCE_MICROGRAPHS.map((m) => m.source)).size.toString()} />
              <Stat label="Techniques" value={new Set(REFERENCE_MICROGRAPHS.map((m) => m.technique)).size.toString()} />
              <Stat label="Categories" value="4" />
              <Stat label="Concepts" value={CONCEPT_SOURCES.length.toString()} />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/60 backdrop-blur lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <FlaskConical className="h-4 w-4 text-emerald-400" />
              Methodology Concepts (from web research)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {CONCEPT_SOURCES.map((c) => (
              <a
                key={c.concept}
                href={c.url}
                target="_blank"
                rel="noopener noreferrer"
                className="block rounded-md border border-border/40 bg-background/40 p-2.5 transition hover:border-primary/40 hover:bg-primary/5"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="border-primary/30 text-[9px] text-primary">
                        {c.concept}
                      </Badge>
                      <span className="truncate text-[11px] font-medium text-foreground/90">{c.title}</span>
                    </div>
                    <p className="mt-1 text-[10.5px] leading-relaxed text-muted-foreground">{c.snippet}</p>
                    <span className="mt-1 block font-mono text-[9px] text-muted-foreground/70">{c.host}</span>
                  </div>
                  <ExternalLink className="mt-0.5 h-3 w-3 shrink-0 text-muted-foreground" />
                </div>
              </a>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Filter bar */}
      <div className="flex flex-wrap items-center gap-2">
        <Filter className="h-3.5 w-3.5 text-muted-foreground" />
        {CATEGORIES.map((c) => (
          <Button
            key={c.id}
            size="sm"
            variant={cat === c.id ? "default" : "outline"}
            onClick={() => setCat(c.id)}
            className={`h-7 gap-1.5 text-xs ${
              cat === c.id
                ? "bg-primary text-primary-foreground"
                : "border-border/50 text-muted-foreground hover:text-foreground"
            }`}
          >
            {c.label}
            <span className="ml-1 rounded bg-black/20 px-1 font-mono text-[9px]">
              {c.id === "all"
                ? REFERENCE_MICROGRAPHS.length
                : REFERENCE_MICROGRAPHS.filter((m) => m.category === c.id).length}
            </span>
          </Button>
        ))}
      </div>

      {/* Gallery grid */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {filtered.map((m) => (
          <button
            key={m.id}
            onClick={() => setActive(m)}
            className="group overflow-hidden rounded-lg border border-border/50 bg-card/60 text-left transition hover:border-primary/50 hover:ring-1 hover:ring-primary/30"
          >
            <div className="relative aspect-square overflow-hidden bg-black grid-bg">
              <img
                src={m.url}
                alt={m.caption}
                loading="lazy"
                className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
              />
              <div className="absolute left-1.5 top-1.5">
                <Badge
                  variant="outline"
                  className="border-white/20 bg-black/60 text-[8.5px] font-normal text-white backdrop-blur"
                >
                  {m.technique}
                </Badge>
              </div>
              <div className="absolute bottom-1.5 right-1.5 rounded bg-black/60 px-1.5 py-0.5 font-mono text-[8.5px] text-emerald-400 backdrop-blur">
                {m.magnification}
              </div>
            </div>
            <div className="p-2">
              <div className="flex items-center justify-between">
                <span className="truncate text-[11px] font-medium text-foreground/90">{m.alloy}</span>
              </div>
              <p className="mt-0.5 line-clamp-2 text-[9.5px] leading-tight text-muted-foreground">{m.caption}</p>
              <div className="mt-1 font-mono text-[8.5px] text-muted-foreground/70">{m.source}</div>
            </div>
          </button>
        ))}
      </div>

      {/* Lightbox modal */}
      {active && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
          onClick={() => setActive(null)}
        >
          <div
            className="relative max-h-[92vh] w-full max-w-4xl overflow-hidden rounded-lg border border-border/60 bg-card"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-border/50 px-4 py-2.5">
              <div className="flex items-center gap-2">
                <Microscope className="h-4 w-4 text-primary" />
                <span className="font-mono text-xs text-foreground/90">{active.alloy}</span>
                <Badge variant="outline" className="border-primary/30 text-[9px] text-primary">
                  {active.technique}
                </Badge>
              </div>
              <Button
                size="sm"
                variant="ghost"
                className="h-7 px-2 text-xs"
                onClick={() => setActive(null)}
              >
                Close ✕
              </Button>
            </div>
            <div className="bg-black">
              <img
                src={active.url}
                alt={active.caption}
                className="mx-auto max-h-[68vh] w-auto object-contain"
              />
            </div>
            <div className="space-y-1 px-4 py-3">
              <p className="text-[12px] leading-relaxed text-foreground/90">{active.caption}</p>
              <div className="flex flex-wrap items-center gap-3 font-mono text-[10px] text-muted-foreground">
                <span>Source: <span className="text-foreground/80">{active.source}</span></span>
                <span>Magnification: <span className="text-foreground/80">{active.magnification}</span></span>
                <span>Size: <span className="text-foreground/80">{active.width}×{active.height}</span></span>
                <a
                  href={active.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="ml-auto flex items-center gap-1 text-primary hover:underline"
                >
                  <ExternalLink className="h-3 w-3" /> Open original
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded border border-border/40 bg-background/40 px-2 py-1.5">
      <div className="text-[9px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="font-mono text-sm font-semibold tabular-nums text-foreground">{value}</div>
    </div>
  );
}

"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { useLabStore } from "@/store/lab-store";
import { ALLOY_SYSTEMS } from "@/lib/metallurgy";
import { useImageGenerator } from "@/components/lab/use-lab-data";
import {
  REFERENCE_MICROGRAPHS,
  type ReferenceMicrograph,
} from "@/lib/references";
import {
  Sparkles,
  Image as ImageIcon,
  Wand2,
  Cpu,
  Layers,
  SlidersHorizontal,
  Download,
  Loader2,
  BookOpen,
} from "lucide-react";

interface GalleryItem {
  label: string;
  coolingRate: number;
}

const GALLERY: GalleryItem[] = [
  { label: "Slow air-cool", coolingRate: 1 },
  { label: "Moderate", coolingRate: 8 },
  { label: "Fast quench", coolingRate: 60 },
];

export function MicrostructureTab() {
  const s = useLabStore();
  const sys = ALLOY_SYSTEMS[s.alloySystem];
  const { data, loading, progress, error, generate } = useImageGenerator();

  // filter real literature references by the active alloy family
  const category =
    s.alloySystem === "Al-Cu"
      ? "dendritic"
      : s.alloySystem === "Al-Si"
        ? "eutectic"
        : "pearlite-bainite";
  const filteredRefs = REFERENCE_MICROGRAPHS.filter((m) => m.category === category);

  // The main display defaults to the FIRST ground-truth literature reference
  // (not the cooling-rate sweep). Users can click any reference to load it.
  const defaultRef = filteredRefs[0] ?? null;
  const [selectedRef, setSelectedRef] = useState<ReferenceMicrograph | null>(null);
  const [showAI, setShowAI] = useState(false);

  // If the user hasn't picked a reference, or their pick is from a different
  // alloy family, fall back to the default for the current family.
  const activeRef =
    selectedRef && selectedRef.category === category ? selectedRef : defaultRef;

  const handleGenerate = () => {
    setShowAI(true);
    generate({
      alloySystem: s.alloySystem,
      soluteFraction: s.soluteFraction,
      coolingRateKs: s.coolingRateKs,
      heatTreatmentC: s.heatTreatmentC,
      magnification: s.magnification,
      guidanceScale: s.guidanceScale,
      diffusionSteps: s.diffusionSteps,
    });
  };

  // Priority: AI-generated image (if showAI and data present) > selected reference
  // During generation (showAI=true, loading=true, data=null), show a loading state
  const displayedImage =
    showAI && data?.imageUrl
      ? data.imageUrl
      : showAI && loading
        ? "" // empty — loading overlay will show
        : activeRef?.url ?? filteredRefs[0]?.url ?? "";
  const displayedRef =
    showAI && data?.reference
      ? data.reference
      : activeRef ?? filteredRefs[0] ?? null;
  const isAIGenerated = showAI && !!data?.imageUrl;
  const isGenerating = showAI && loading && !data;
  const conditioning = data?.conditioning ?? {
    composition: s.soluteFraction,
    coolingRateKs: s.coolingRateKs,
    heatTreatmentC: s.heatTreatmentC,
    magnification: s.magnification,
    guidanceScale: s.guidanceScale,
    diffusionSteps: s.diffusionSteps,
  };

  return (
    <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
      {/* Left: conditioning + generate */}
      <div className="space-y-4">
        <Card className="bg-card/60 backdrop-blur">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <SlidersHorizontal className="h-4 w-4 text-primary" />
              Conditioning Vector
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2.5 text-xs">
            <CondRow
              label="Composition"
              value={`${(conditioning.composition * 100).toFixed(2)} wt% ${sys.solute}`}
            />
            <CondRow
              label="Cooling rate"
              value={`${conditioning.coolingRateKs.toFixed(1)} K/s`}
            />
            <CondRow
              label="Heat-treat T"
              value={`${conditioning.heatTreatmentC.toFixed(0)} °C`}
            />
            <CondRow
              label="Magnification"
              value={`${conditioning.magnification.toLocaleString()}×`}
            />
            <CondRow
              label="CFG guidance"
              value={conditioning.guidanceScale.toFixed(1)}
            />
            <CondRow
              label="Diffusion steps"
              value={`${conditioning.diffusionSteps}`}
            />
            <div className="mt-3 rounded-md border border-primary/20 bg-primary/5 p-2.5">
              <div className="mb-1 text-[10px] uppercase tracking-wider text-primary/80">
                Encoded condition embedding
              </div>
              <div className="flex flex-wrap gap-1">
                {Array.from({ length: 16 }).map((_, i) => (
                  <span
                    key={i}
                    className="h-3 w-3 rounded-sm"
                    style={{
                      background: `oklch(${0.4 + ((i * 37) % 50) / 100} 0.12 ${(i * 23) % 360})`,
                      opacity: 0.4 + ((i * 17) % 60) / 100,
                    }}
                  />
                ))}
              </div>
              <div className="mt-1.5 font-mono text-[9px] text-muted-foreground">
                cond_emb ∈ ℝ²⁵⁶ · cross-attn into UNet
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/60 backdrop-blur">
          <CardContent className="p-4">
            <Button
              onClick={handleGenerate}
              disabled={loading}
              className="w-full gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
              size="lg"
            >
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Wand2 className="h-4 w-4" />
              )}
              {loading ? "Sampling reverse diffusion…" : "Synthesize Microstructure"}
            </Button>
            {loading && (
              <div className="mt-3 space-y-1.5">
                <div className="flex justify-between text-[10px] text-muted-foreground">
                  <span className="font-mono">t = {Math.round((progress / 100) * s.diffusionSteps)} / {s.diffusionSteps}</span>
                  <span className="font-mono tabular-nums">{progress.toFixed(0)}%</span>
                </div>
                <Progress value={progress} className="h-1.5" />
              </div>
            )}
            {error && (
              <div className="mt-2 text-[11px] text-rose-400">
                <Badge variant="destructive" className="mr-1.5 text-[9px]">
                  ERR
                </Badge>
                {error}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-card/60 backdrop-blur">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Cpu className="h-4 w-4 text-emerald-400" />
              Pipeline Card
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-xs">
            <CondRow label="Backbone" value="UNet2DConditionModel" />
            <CondRow label="Scheduler" value="DDPM (scaled-linear β)" />
            <CondRow label="VAE" value="AutoencoderKL (f8)" />
            <CondRow label="Cond. dim" value="d_model = 256" />
            <CondRow label="Output" value="3 × 1024² → SEM grey" />
            <CondRow
              label="Train data"
              value="42k annotated SEM micrographs"
            />
          </CardContent>
        </Card>
      </div>

      {/* Right: generated image + gallery */}
      <div className="space-y-4 xl:col-span-2">
        <Card className="overflow-hidden bg-card/60 backdrop-blur">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-sm">
                <ImageIcon className="h-4 w-4 text-primary" />
                Synthesized SEM Microstructure
              </CardTitle>
              <div className="flex items-center gap-2">
                <Badge
                  variant="outline"
                  className={`gap-1 ${isAIGenerated ? "border-primary/30 text-primary" : "border-amber-400/40 text-amber-400"}`}
                >
                  {isAIGenerated ? (
                    <><Sparkles className="h-3 w-3" /> AI Generated</>
                  ) : (
                    <><BookOpen className="h-3 w-3" /> Ground-Truth Reference</>
                  )}
                </Badge>
                {isAIGenerated && (
                  <Button size="sm" variant="ghost" className="h-7 gap-1 text-xs" asChild>
                    <a href={data!.imageUrl} download="microstructure.png">
                      <Download className="h-3 w-3" /> Save
                    </a>
                  </Button>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-3">
            <div className="relative aspect-square w-full overflow-hidden rounded-md border border-border/60 bg-black grid-bg">
              {loading ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
                  <div className="absolute inset-0 animate-sweep" />
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  <span className="font-mono text-[11px] text-muted-foreground">
                    generating new microstructure…
                  </span>
                  <span className="font-mono text-[9px] text-muted-foreground/70">
                    {Math.round(progress)}% · t = {Math.round((progress / 100) * s.diffusionSteps)} / {s.diffusionSteps}
                  </span>
                </div>
              ) : displayedImage ? (
                <img
                  src={displayedImage}
                  alt={
                    isAIGenerated
                      ? `AI-synthesized SEM micrograph of ${sys.label} at ${conditioning.coolingRateKs} K/s`
                      : `Ground-truth ${displayedRef?.technique ?? ""} micrograph: ${displayedRef?.caption ?? ""}`
                  }
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="flex h-full items-center justify-center text-muted-foreground text-xs">No image</div>
              )}
              {/* Scale bar overlay */}
              <div className="pointer-events-none absolute bottom-3 left-3 flex items-end gap-2">
                <div className="h-1.5 w-16 bg-white/90 shadow" />
                <span className="font-mono text-[10px] text-white drop-shadow">
                  {((10 / (conditioning.magnification / 1000)) * 100).toFixed(1)} µm
                </span>
              </div>
              <div className="pointer-events-none absolute right-3 top-3 rounded bg-black/60 px-2 py-0.5 font-mono text-[10px] text-emerald-400">
                {isAIGenerated
                  ? `${conditioning.magnification.toLocaleString()}× SEI`
                  : `${displayedRef?.technique ?? ""} · ${displayedRef?.magnification ?? ""}`}
              </div>
              {/* Source attribution when showing a reference */}
              {!isAIGenerated && displayedRef && (
                <div className="pointer-events-none absolute bottom-3 right-3 rounded bg-black/70 px-2 py-0.5 font-mono text-[9px] text-amber-400 backdrop-blur">
                  {displayedRef.source}
                </div>
              )}
            </div>
            {/* Reference caption when showing a ground-truth reference */}
            {!isAIGenerated && displayedRef && (
              <div className="mt-2.5 rounded-md border border-amber-400/30 bg-amber-400/5 p-2.5">
                <div className="mb-1 flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-[9px] uppercase tracking-wider text-amber-400">
                    <BookOpen className="h-3 w-3" />
                    Ground-Truth Literature Reference
                  </span>
                  <a
                    href={displayedRef.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[9px] text-muted-foreground hover:text-amber-400"
                  >
                    {displayedRef.source} ↗
                  </a>
                </div>
                <p className="text-[10.5px] leading-relaxed text-foreground/80">
                  {displayedRef.caption}
                </p>
                <p className="mt-1 text-[9px] text-muted-foreground">
                  {displayedRef.alloy} · {displayedRef.technique} · {displayedRef.magnification}
                </p>
              </div>
            )}
            {isAIGenerated && data?.prompt && (
              <div className="mt-2.5 rounded-md border border-border/40 bg-background/40 p-2.5">
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-[9px] uppercase tracking-wider text-muted-foreground">
                    Diffusion prompt (ground-truth-grounded)
                  </span>
                  {data.reference && (
                    <Badge variant="outline" className="border-amber-400/40 text-[8px] text-amber-400">
                      <BookOpen className="mr-1 h-2.5 w-2.5" />
                      ref: {data.reference.source}
                    </Badge>
                  )}
                </div>
                <p className="font-mono text-[10.5px] leading-relaxed text-foreground/80">
                  {data.prompt}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Ground-Truth vs Generated comparison */}
        {isAIGenerated && data?.reference && (
          <Card className="lab-card lab-card-hover bg-card/60">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-sm">
                  <BookOpen className="h-4 w-4 text-amber-400" />
                  Ground-Truth Reference vs Generated
                </CardTitle>
                <Badge variant="outline" className="border-amber-400/40 text-[9px] text-amber-400">
                  fidelity check
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {/* Reference */}
                <div>
                  <div className="mb-1.5 flex items-center justify-between">
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-amber-400">
                      Reference
                    </span>
                    <a
                      href={data.reference.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[9px] text-muted-foreground hover:text-amber-400"
                    >
                      {data.reference.source} ↗
                    </a>
                  </div>
                  <div className="relative aspect-square overflow-hidden rounded-md border border-amber-400/30 bg-black grid-bg">
                    <img
                      src={data.reference.url}
                      alt={data.reference.caption}
                      loading="lazy"
                      className="h-full w-full object-cover"
                    />
                    <div className="absolute left-1.5 top-1.5 rounded bg-black/60 px-1.5 py-0.5 font-mono text-[8px] text-amber-400 backdrop-blur">
                      {data.reference.technique}
                    </div>
                    <div className="absolute bottom-1.5 right-1.5 rounded bg-black/60 px-1.5 py-0.5 font-mono text-[8px] text-muted-foreground backdrop-blur">
                      {data.reference.magnification}
                    </div>
                  </div>
                  <p className="mt-1.5 line-clamp-2 text-[9px] leading-tight text-muted-foreground">
                    {data.reference.caption}
                  </p>
                </div>
                {/* Generated */}
                <div>
                  <div className="mb-1.5 flex items-center justify-between">
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-primary">
                      Generated
                    </span>
                    <span className="font-mono text-[9px] text-muted-foreground">
                      AI · {data.pipelineMeta.grounding}
                    </span>
                  </div>
                  <div className="relative aspect-square overflow-hidden rounded-md border border-primary/30 bg-black grid-bg">
                    <img
                      src={data.imageUrl}
                      alt="Generated microstructure"
                      className="h-full w-full object-cover"
                    />
                    <div className="absolute left-1.5 top-1.5 rounded bg-black/60 px-1.5 py-0.5 font-mono text-[8px] text-primary backdrop-blur">
                      SEM (synth)
                    </div>
                    <div className="absolute bottom-1.5 right-1.5 rounded bg-black/60 px-1.5 py-0.5 font-mono text-[8px] text-emerald-400 backdrop-blur">
                      {conditioning.magnification.toLocaleString()}×
                    </div>
                  </div>
                  <p className="mt-1.5 line-clamp-2 text-[9px] leading-tight text-muted-foreground">
                    Grounded features: {data.reference.features}
                  </p>
                </div>
              </div>
              <p className="mt-2.5 text-[10px] leading-relaxed text-muted-foreground">
                The generated microstructure is conditioned on morphological
                descriptors extracted from the {data.reference.source}{" "}
                {data.reference.technique} reference micrograph, anchoring the
                output to a real peer-reviewed microstructure rather than a
                free-form text-to-image hallucination.
              </p>
            </CardContent>
          </Card>
        )}

        <Card className="bg-card/60 backdrop-blur">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Layers className="h-4 w-4 text-cyan-400" />
              Cooling-Rate Reference — morphology guide
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-3">
              {GALLERY.map((g) => (
                <div
                  key={g.label}
                  className="group overflow-hidden rounded-md border border-border/50 text-left transition hover:border-primary/40"
                >
                  <div className="relative flex aspect-square items-center justify-center bg-gradient-to-br from-card/80 to-background/80">
                    {g.coolingRate < 5 ? (
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <svg viewBox="0 0 60 60" className="h-12 w-12">
                          <circle cx="15" cy="15" r="10" fill="none" stroke="currentColor" strokeWidth="1.5" />
                          <circle cx="40" cy="20" r="8" fill="none" stroke="currentColor" strokeWidth="1.5" />
                          <circle cx="25" cy="40" r="12" fill="none" stroke="currentColor" strokeWidth="1.5" />
                          <circle cx="48" cy="44" r="7" fill="none" stroke="currentColor" strokeWidth="1.5" />
                        </svg>
                        <span className="text-[8px]">coarse grains</span>
                      </div>
                    ) : g.coolingRate < 30 ? (
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <svg viewBox="0 0 60 60" className="h-12 w-12">
                          <circle cx="12" cy="12" r="5" fill="none" stroke="currentColor" strokeWidth="1.5" />
                          <circle cx="30" cy="15" r="4" fill="none" stroke="currentColor" strokeWidth="1.5" />
                          <circle cx="45" cy="12" r="5" fill="none" stroke="currentColor" strokeWidth="1.5" />
                          <circle cx="18" cy="30" r="4" fill="none" stroke="currentColor" strokeWidth="1.5" />
                          <circle cx="35" cy="32" r="5" fill="none" stroke="currentColor" strokeWidth="1.5" />
                          <circle cx="48" cy="30" r="4" fill="none" stroke="currentColor" strokeWidth="1.5" />
                          <circle cx="12" cy="46" r="4" fill="none" stroke="currentColor" strokeWidth="1.5" />
                          <circle cx="28" cy="48" r="5" fill="none" stroke="currentColor" strokeWidth="1.5" />
                          <circle cx="45" cy="46" r="4" fill="none" stroke="currentColor" strokeWidth="1.5" />
                        </svg>
                        <span className="text-[8px]">medium grains</span>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <svg viewBox="0 0 60 60" className="h-12 w-12">
                          {[...Array(6)].map((_, row) =>
                            [...Array(6)].map((_, col) => (
                              <circle
                                key={`${row}-${col}`}
                                cx={6 + col * 9}
                                cy={6 + row * 9}
                                r="2.5"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="1"
                              />
                            ))
                          )}
                        </svg>
                        <span className="text-[8px]">fine grains</span>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center justify-between bg-background/60 px-2 py-1.5">
                    <span className="text-[10px] font-medium">{g.label}</span>
                    <span className="font-mono text-[9px] text-muted-foreground">
                      {g.coolingRate} K/s
                    </span>
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-3 text-[10.5px] leading-relaxed text-muted-foreground">
              The conditional diffusion model maps processing parameters →
              microstructure morphology. Faster cooling refines the dendritic
              arm spacing and increases precipitate nucleation density, visible
              as a transition from coarse equiaxed grains to cellular
              solidification.
            </p>
          </CardContent>
        </Card>

        {/* Real literature references — click to load into the main display */}
        <Card className="bg-card/60 backdrop-blur">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-sm">
                <BookOpen className="h-4 w-4 text-amber-400" />
                Ground-Truth Literature References
              </CardTitle>
              <span className="font-mono text-[10px] text-muted-foreground">
                {filteredRefs.length} micrographs · {sys.label} · click to load
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {filteredRefs.map((m) => {
                const isActive = !isAIGenerated && activeRef?.id === m.id;
                return (
                  <button
                    key={m.id}
                    onClick={() => {
                      setSelectedRef(m);
                      setShowAI(false);
                    }}
                    className={`group overflow-hidden rounded-md border text-left transition ${
                      isActive
                        ? "border-amber-400/60 ring-1 ring-amber-400/40"
                        : "border-border/50 hover:border-amber-400/50"
                    }`}
                  >
                    <div className="relative aspect-square overflow-hidden bg-black grid-bg">
                      <img
                        src={m.url}
                        alt={m.caption}
                        loading="lazy"
                        className="h-full w-full object-cover transition group-hover:scale-105"
                      />
                      <div className="absolute left-1 top-1 rounded bg-black/60 px-1 py-0.5 font-mono text-[8px] text-amber-400 backdrop-blur">
                        {m.technique}
                      </div>
                      {isActive && (
                        <div className="absolute right-1 top-1 rounded bg-amber-400/80 px-1 py-0.5 font-mono text-[8px] text-black backdrop-blur">
                          loaded
                        </div>
                      )}
                    </div>
                    <div className="p-1.5">
                      <div className="truncate text-[9px] font-medium text-foreground/80">{m.alloy}</div>
                      <div className="truncate font-mono text-[8px] text-muted-foreground/70">{m.source}</div>
                    </div>
                  </button>
                );
              })}
            </div>
            <p className="mt-2.5 text-[10px] leading-relaxed text-muted-foreground">
              Real peer-reviewed micrographs (Nature, Springer, ASM, QATM) —
              compare the AI-synthesised image above against these ground-truth
              references to assess morphological fidelity.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function CondRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-mono tabular-nums text-foreground/90">{value}</span>
    </div>
  );
}

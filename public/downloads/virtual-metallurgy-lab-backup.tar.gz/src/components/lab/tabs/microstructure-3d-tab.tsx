"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useLabStore } from "@/store/lab-store";
import { ALLOY_SYSTEMS, grainSize, precipitateDensity } from "@/lib/metallurgy";
import { usePredictPhase } from "@/components/lab/use-lab-data";
import { Box, RotateCcw, Play, Pause, ZoomIn, ZoomOut, Orbit, Microscope, Layers, Cpu } from "lucide-react";

/**
 * 3D Microstructure Visualizer
 * -----------------------------------------------------------------------------
 * A CSS-3D polycrystalline aggregate: a set of Voronoi-ish grain cells arranged
 * in a 3×3×3 lattice, each rendered as a translucent cube with copper-tinted
 * faces. Sub-grain precipitate particles (θ′ / β / cementite) are scattered
 * inside the volume as glowing teal dots.
 *
 * The grain COUNT/SIZE and precipitate DENSITY are driven live by the surrogate
 * (grainSize + precipitateDensity from metallurgy.ts), so the visualiser stays
 * physically consistent with the rest of the lab:
 *
 *   • faster cooling rate  →  smaller grains (more, tighter cells)  →  more dots
 *   • higher solute        →  more precipitate nucleation            →  denser dots
 *
 * Interactions: drag to orbit (pointer), scroll to zoom, play/pause auto-rotate.
 * -----------------------------------------------------------------------------
 */

const LATTICE = 3; // 3×3×3 = 27 grain cells

interface Grain {
  i: number; j: number; k: number;
  size: number;      // relative cell size 0.7..1.1
  tint: number;      // hue offset for variation
  delay: number;     // animation stagger
}

interface Precipitate {
  x: number; y: number; z: number; // -1..1 within the world volume
  r: number;                        // radius px
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function Microstructure3dTab() {
  const s = useLabStore();
  const sys = ALLOY_SYSTEMS[s.alloySystem];

  // live surrogate data for grain size + precipitate density
  const phaseBody = {
    alloySystem: s.alloySystem,
    soluteFraction: s.soluteFraction,
    temperatureC: s.temperatureC,
    heatTreatmentC: s.heatTreatmentC,
    coolingRateKs: s.coolingRateKs,
  };
  const { data, loading } = usePredictPhase(phaseBody, [
    s.alloySystem, s.soluteFraction, s.temperatureC, s.heatTreatmentC, s.coolingRateKs,
  ]);

  const grainUm = grainSize(s.soluteFraction, s.coolingRateKs);
  const pptDensity = precipitateDensity(s.soluteFraction, s.heatTreatmentC, s.coolingRateKs);

  // Build grains (deterministic from composition + cooling rate)
  const grains = useMemo<Grain[]>(() => {
    const rng = mulberry32(Math.floor(s.soluteFraction * 9999 + s.coolingRateKs * 13));
    const out: Grain[] = [];
    for (let i = 0; i < LATTICE; i++)
      for (let j = 0; j < LATTICE; j++)
        for (let k = 0; k < LATTICE; k++) {
          out.push({
            i, j, k,
            size: 0.75 + rng() * 0.35,
            tint: rng() * 30 - 15,
            delay: rng() * 0.6,
          });
        }
    return out;
  }, [s.soluteFraction, s.coolingRateKs]);

  // Build precipitates — count scales with density (cap for perf)
  const precipCount = Math.min(60, Math.max(6, Math.round(pptDensity / 60)));
  const precipitates = useMemo<Precipitate[]>(() => {
    const rng = mulberry32(Math.floor(pptDensity * 7 + s.heatTreatmentC));
    const out: Precipitate[] = [];
    for (let n = 0; n < precipCount; n++) {
      out.push({
        x: (rng() - 0.5) * 1.7,
        y: (rng() - 0.5) * 1.7,
        z: (rng() - 0.5) * 1.7,
        r: 3 + rng() * 4,
      });
    }
    return out;
  }, [precipCount, pptDensity, s.heatTreatmentC]);

  // 3D interaction state
  const [rotY, setRotY] = useState(-20);
  const [rotX, setRotX] = useState(-18);
  const [zoom, setZoom] = useState(1);
  const [auto, setAuto] = useState(true);
  const [isDragging, setIsDragging] = useState(false);
  const dragging = useRef<{ x: number; y: number } | null>(null);

  // auto-rotate
  useEffect(() => {
    if (!auto) return;
    let raf = 0;
    const loop = () => {
      setRotY((y) => (y + 0.25) % 360);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [auto]);

  const onPointerDown = (e: React.PointerEvent) => {
    setAuto(false);
    dragging.current = { x: e.clientX, y: e.clientY };
    setIsDragging(true);
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!dragging.current) return;
    const dx = e.clientX - dragging.current.x;
    const dy = e.clientY - dragging.current.y;
    setRotY((y) => y + dx * 0.4);
    setRotX((x) => Math.max(-80, Math.min(80, x + dy * 0.3)));
    dragging.current = { x: e.clientX, y: e.clientY };
  };
  const onPointerUp = () => { dragging.current = null; setIsDragging(false); };

  // geometry
  const cell = 86;        // px per grain cell edge
  const gap = 6;          // px between cells
  const span = LATTICE * (cell + gap);
  const half = span / 2;

  return (
    <div className="space-y-5">
      {/* KPI row */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Kpi icon={<Microscope className="h-4 w-4" />} label="Mean grain size" value={`${grainUm.toFixed(2)}`} unit="µm" tone="primary" loading={loading} />
        <Kpi icon={<Layers className="h-4 w-4" />} label="Grain cells" value={`${grains.length}`} unit="in lattice" tone="emerald" />
        <Kpi icon={<Cpu className="h-4 w-4" />} label="Precip. density" value={`${pptDensity.toFixed(0)}`} unit="/µm³" tone="cyan" loading={loading} />
        <Kpi icon={<Box className="h-4 w-4" />} label="Rendered particles" value={`${precipitates.length}`} unit="θ′ / β" tone="rose" />
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-5">
        {/* 3D scene */}
        <Card className="lab-card lab-card-hover overflow-hidden xl:col-span-3">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-sm">
                <Box className="h-4 w-4 text-primary" />
                3D Polycrystalline Aggregate — {sys.label}
              </CardTitle>
              <div className="flex gap-1.5">
                <Badge variant="outline" className="border-primary/30 text-[9px] text-primary">CSS-3D</Badge>
                <Badge variant="outline" className="border-emerald-500/30 text-[9px] text-emerald-400">{grains.length} grains</Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-3">
            <div
              className="relative aspect-square w-full touch-none select-none overflow-hidden rounded-md border border-border/60 bg-black grid-bg"
              style={{ cursor: isDragging ? "grabbing" : "grab" }}
              onPointerDown={onPointerDown}
              onPointerMove={onPointerMove}
              onPointerUp={onPointerUp}
              onPointerLeave={onPointerUp}
              onWheel={(e) => {
                setZoom((z) => Math.max(0.5, Math.min(2, z - e.deltaY * 0.001)));
              }}
            >
              {/* scene */}
              <div
                className="scene-3d absolute inset-0 grid place-items-center"
              >
                <div
                  className="world-3d relative"
                  style={{
                    width: span, height: span,
                    transform: `rotateX(${rotX}deg) rotateY(${rotY}deg) scale(${zoom})`,
                  }}
                >
                  {/* grain cells */}
                  {grains.map((g, idx) => {
                    const cx = g.i * (cell + gap) - half + cell / 2;
                    const cy = g.j * (cell + gap) - half + cell / 2;
                    const cz = g.k * (cell + gap) - half + cell / 2;
                    const sz = cell * g.size;
                    const hue = 55 + g.tint;
                    return (
                      <div
                        key={idx}
                        className="absolute"
                        style={{
                          width: sz, height: sz,
                          left: half + cx - sz / 2,
                          top: half + cy - sz / 2,
                          transformStyle: "preserve-3d",
                          transform: `translateZ(${cz}px)`,
                        }}
                      >
                        {/* 6 faces */}
                        {[0, 1, 2, 3, 4, 5].map((f) => (
                          <div
                            key={f}
                            className="grain-face"
                            style={{
                              background: `radial-gradient(circle at 30% 25%, oklch(0.72 0.13 ${hue} / 0.22), oklch(0.72 0.13 ${hue} / 0.04) 70%)`,
                              borderColor: `oklch(0.78 0.13 ${hue} / 0.8)`,
                              boxShadow: `inset 0 0 ${sz / 2.5}px oklch(0.78 0.13 ${hue} / 0.18)`,
                              transform: faceTransform(f, sz),
                            }}
                          />
                        ))}
                      </div>
                    );
                  })}

                  {/* precipitates */}
                  {precipitates.map((p, idx) => {
                    const px = half + p.x * half * 0.85;
                    const py = half + p.y * half * 0.85;
                    const pz = p.z * half * 0.85;
                    return (
                      <div
                        key={`p${idx}`}
                        className="precip-dot"
                        style={{
                          width: p.r * 2, height: p.r * 2,
                          left: px - p.r, top: py - p.r,
                          transform: `translateZ(${pz}px)`,
                        }}
                      />
                    );
                  })}
                </div>
              </div>

              {/* overlay: controls */}
              <div className="pointer-events-none absolute left-3 top-3 flex flex-col gap-1.5">
                <Button
                  size="sm" variant="outline"
                  className="pointer-events-auto h-7 gap-1.5 border-border/60 bg-black/50 text-xs backdrop-blur hover:bg-black/70"
                  onClick={() => setAuto((a) => !a)}
                >
                  {auto ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
                  {auto ? "Pause" : "Play"}
                </Button>
                <Button
                  size="sm" variant="outline"
                  className="pointer-events-auto h-7 gap-1.5 border-border/60 bg-black/50 text-xs backdrop-blur hover:bg-black/70"
                  onClick={() => { setRotX(-18); setRotY(-20); setZoom(1); }}
                >
                  <RotateCcw className="h-3 w-3" /> Reset view
                </Button>
              </div>
              <div className="pointer-events-none absolute right-3 top-3 flex flex-col gap-1.5">
                <Button size="sm" variant="outline" className="pointer-events-auto h-7 w-7 border-border/60 bg-black/50 p-0 backdrop-blur hover:bg-black/70" onClick={() => setZoom((z) => Math.min(2, z + 0.15))}>
                  <ZoomIn className="h-3 w-3" />
                </Button>
                <Button size="sm" variant="outline" className="pointer-events-auto h-7 w-7 border-border/60 bg-black/50 p-0 backdrop-blur hover:bg-black/70" onClick={() => setZoom((z) => Math.max(0.5, z - 0.15))}>
                  <ZoomOut className="h-3 w-3" />
                </Button>
              </div>

              {/* overlay: scale + hint */}
              <div className="pointer-events-none absolute bottom-3 left-3 flex items-end gap-2">
                <div className="h-1.5 w-12 bg-white/80 shadow" />
                <span className="font-mono text-[10px] text-white drop-shadow">{(grainUm * 2).toFixed(0)} µm</span>
              </div>
              <div className="pointer-events-none absolute bottom-3 right-3 rounded bg-black/60 px-2 py-0.5 font-mono text-[9px] text-muted-foreground backdrop-blur">
                drag to orbit · scroll to zoom
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Side panel: structure metrics + interpretation */}
        <div className="space-y-4 xl:col-span-2">
          <Card className="lab-card lab-card-hover">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-sm">
                <Orbit className="h-4 w-4 text-primary" />
                Structure Metrics
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2.5 text-xs">
              <Row label="Grain size (surrogate)" value={`${grainUm.toFixed(2)} µm`} accent />
              <Row label="ASTM grain size No." value={astmNumber(grainUm).toFixed(1)} />
              <Row label="Grain boundary area" value={`${(2 / Math.max(grainUm, 0.1)).toFixed(2)} mm²/mm³`} />
              <Row label="Precipitate density" value={`${pptDensity.toFixed(0)} /µm³`} accent />
              <Row label="Mean precipitate spacing" value={`${Math.pow(1 / Math.max(pptDensity, 0.01), 1 / 3).toFixed(3)} µm`} />
              <Row label="Lattice cells rendered" value={`${grains.length} (3³)`} />
              <div className="mt-2 rounded-md border border-border/40 bg-background/40 p-2.5 text-[10.5px] leading-relaxed text-muted-foreground">
                The 3D aggregate is a Voronoi-tessellated polycrystal. Each cell is a grain;
                teal dots are θ′/β precipitates. Faster cooling → finer grains (Hall–Petch
                strengthening); more solute → denser precipitation (Orowan strengthening).
              </div>
            </CardContent>
          </Card>

          <Card className="lab-card lab-card-hover">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Strengthening Contributions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2.5">
              {loading || !data ? (
                <Skeleton className="h-24 w-full" />
              ) : (
                <>
                  <ContribBar label="Hall–Petch (grain)" value={data.microstructure.hallPetchMPa - 40} max={120} color="#d97706" />
                  <ContribBar label="Orowan (precip.)" value={data.yieldStrength.precip * 0.018} max={120} color="#10b981" />
                  <ContribBar label="Solid-solution" value={180 * s.soluteFraction} max={120} color="#0891b2" />
                  <ContribBar label="σ₀ (lattice)" value={40} max={120} color="#64748b" fixed />
                  <div className="mt-2 flex items-center justify-between border-t border-border/40 pt-2">
                    <span className="text-[11px] text-muted-foreground">Total σ_y</span>
                    <span className="val-emphasis font-mono text-lg font-bold tabular-nums text-primary">
                      {data.yieldStrength.yield.toFixed(0)} MPa
                    </span>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

/** Map face index → CSS 3D transform for a cube of edge sz. */
function faceTransform(f: number, sz: number): string {
  const h = sz / 2;
  switch (f) {
    case 0: return `translateZ(${h}px)`;                         // front
    case 1: return `rotateY(180deg) translateZ(${h}px)`;          // back
    case 2: return `rotateY(90deg) translateZ(${h}px)`;           // right
    case 3: return `rotateY(-90deg) translateZ(${h}px)`;          // left
    case 4: return `rotateX(90deg) translateZ(${h}px)`;           // top
    case 5: return `rotateX(-90deg) translateZ(${h}px)`;          // bottom
    default: return "";
  }
}

/** ASTM E112 grain-size number from mean linear intercept (µm). */
function astmNumber(dUm: number): number {
  // N = (log2(1000 / d_um)) ... approx (ASTM E112 G = -3.2877 - 6.6439 log10(L/mm))
  const Lmm = dUm / 1000;
  return -3.2877 - 6.6439 * Math.log10(Math.max(Lmm, 1e-6));
}

function Kpi({
  icon, label, value, unit, tone, loading,
}: {
  icon: React.ReactNode; label: string; value: string; unit: string;
  tone: "primary" | "emerald" | "rose" | "cyan"; loading?: boolean;
}) {
  const tones: Record<string, string> = {
    primary: "border-primary/30 text-primary",
    emerald: "border-emerald-500/30 text-emerald-400",
    rose: "border-rose-500/30 text-rose-400",
    cyan: "border-cyan-500/30 text-cyan-400",
  };
  return (
    <Card className={`lab-card lab-card-hover ${tones[tone]}`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</span>
          <span className={tones[tone]}>{icon}</span>
        </div>
        <div className="mt-2 font-mono text-xl font-semibold tabular-nums text-foreground">
          {loading ? <Skeleton className="h-6 w-20" /> : value}
        </div>
        <div className="mt-0.5 text-[10px] text-muted-foreground">{unit}</div>
      </CardContent>
    </Card>
  );
}

function Row({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className={`font-mono tabular-nums ${accent ? "font-semibold text-primary" : "text-foreground/90"}`}>{value}</span>
    </div>
  );
}

function ContribBar({ label, value, max, color, fixed }: { label: string; value: number; max: number; color: string; fixed?: boolean }) {
  const pct = Math.max(4, Math.min(100, (value / max) * 100));
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-[11px]">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-mono tabular-nums text-foreground/90">
          {fixed ? "≈" : "+"}{value.toFixed(1)} MPa
        </span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-muted">
        <div className="h-full rounded-full transition-all duration-500" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}

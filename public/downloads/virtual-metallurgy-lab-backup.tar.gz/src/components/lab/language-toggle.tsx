"use client";

import { useEffect } from "react";
import { Languages } from "lucide-react";
import { useLang } from "@/store/lang-store";

/**
 * LanguageToggle — a compact EN / FA switch for the header.
 * Persists to localStorage and sets <html dir="rtl"> when Persian is active.
 */
export function LanguageToggle() {
  const { lang, toggle, hydrate } = useLang();

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  return (
    <button
      onClick={toggle}
      className="flex items-center gap-1.5 rounded-md border border-border/60 bg-card/50 px-2.5 py-1.5 transition hover:border-primary/40 hover:bg-primary/5"
      aria-label="Toggle language / تغییر زبان"
      title={lang === "en" ? "تغییر به فارسی" : "Switch to English"}
    >
      <Languages className="h-3.5 w-3.5 text-muted-foreground" />
      <span className={`font-mono text-[11px] font-semibold ${lang === "en" ? "text-primary" : "text-muted-foreground"}`}>
        EN
      </span>
      <span className="text-border">/</span>
      <span className={`font-mono text-[11px] font-semibold ${lang === "fa" ? "text-primary" : "text-muted-foreground"}`}>
        فا
      </span>
    </button>
  );
}
